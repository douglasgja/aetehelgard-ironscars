# Estrutura de Arquivos para Mapas e Biomas - Aethelgard: Iron Scars

## Visão Geral

Este documento detalha a estrutura de arquivos necessária para criar mapas e biomas para o MMORPG "Aethelgard: Iron Scars", seguindo os padrões da Unreal Engine 2.5 utilizados no Lineage 2.

## Estrutura de Diretórios

```
/MapSystem/
│
├── Maps/                      # Arquivos de mapa principal (.unr)
│   ├── Ghalia.unr             # Mapa da Cidade de Ferro
│   ├── VerdantReach.unr       # Mapa da Floresta dos Sylvan Elves
│   ├── ShadowForge.unr        # Mapa da cidade subterrânea dos Umbral Technocrats
│   └── IronFist.unr           # Mapa da Cidadela dos Ironhide Orcs
│
├── Heightmaps/                # Arquivos de heightmap para terrenos
│   ├── Raw/                   # Heightmaps em formato RAW 16-bit
│   │   ├── Ghalia_height.raw
│   │   ├── VerdantReach_height.raw
│   │   └── ...
│   │
│   └── Working/               # Versões de trabalho (PSD, etc)
│       ├── Ghalia_height.psd
│       └── ...
│
├── Textures/                  # Arquivos de textura (.utx)
│   ├── TerrainTextures.utx    # Pacote de texturas de terreno
│   ├── DetailTextures.utx     # Texturas de detalhe para terrenos
│   ├── BiomeTextures.utx      # Texturas específicas de biomas
│   └── ...
│
├── Scripts/                   # Scripts UnrealScript (.uc)
│   ├── Classes/               # Classes de script
│   │   ├── TerrainInfo.uc     # Informações de terreno
│   │   ├── BiomeManager.uc    # Gerenciador de biomas
│   │   └── ...
│   │
│   └── Packages/              # Pacotes compilados (.u)
│       ├── MapSystem.u
│       └── ...
│
├── Config/                    # Arquivos de configuração
│   ├── Biomes/                # Configurações de biomas
│   │   ├── Forest.ini
│   │   ├── Mountain.ini
│   │   ├── Desert.ini
│   │   ├── Swamp.ini
│   │   └── ...
│   │
│   ├── TerrainSettings.ini    # Configurações gerais de terreno
│   └── WorldSettings.ini      # Configurações do mundo
│
└── Tools/                     # Ferramentas auxiliares
    ├── HeightmapConverter/    # Conversor de heightmaps
    ├── TerrainEditor/         # Editor de terreno
    └── BiomeBlender/          # Ferramenta para misturar biomas
```

## Formatos de Arquivo

### Arquivos de Mapa (.unr)
Os arquivos .unr são os mapas principais da Unreal Engine 2.5, contendo todas as informações sobre o terreno, objetos, iluminação e outros elementos do mapa.

### Heightmaps
- **Formato**: RAW 16-bit (recomendado para compatibilidade com UE 2.5)
- **Resolução**: Potências de 2 + 1 (129x129, 257x257, 513x513, 1025x1025)
- **Valor médio**: 32768 (metade do intervalo de 0-65535 para uint16)
- **Alternativas**: BMP 16-bit grayscale, PNG 16-bit grayscale

### Texturas (.utx)
Pacotes de texturas da Unreal Engine contendo:
- Texturas base de terreno (difuso)
- Mapas normais
- Texturas de detalhe
- Texturas específicas de bioma

### Scripts (.uc, .u)
Scripts em UnrealScript para controlar comportamentos de terreno, biomas e elementos ambientais.

## Configuração de Biomas

Cada bioma é definido por um arquivo .ini na pasta Config/Biomes/ com a seguinte estrutura:

```ini
[BiomeSettings]
Name=Forest
Description=Floresta densa com vegetação abundante

[TerrainSettings]
BaseTexture=TerrainTextures.Forest.Base
DetailTexture=DetailTextures.Forest.Detail
NormalMap=TerrainTextures.Forest.Normal
TextureScale=8.0
DetailScale=16.0

[VegetationSettings]
TreeDensity=0.8
GrassDensity=0.9
BushDensity=0.7
TreeTypes=ForestTrees.Oak,ForestTrees.Pine,ForestTrees.Maple
GrassTypes=ForestGrass.Tall,ForestGrass.Short
BushTypes=ForestBushes.Berry,ForestBushes.Fern

[EnvironmentSettings]
AmbientSound=Sounds.Environment.ForestAmbience
WeatherTypes=Weather.Rain,Weather.Fog
LightColor=(R=120,G=140,B=100)
FogColor=(R=180,G=200,B=180)
FogDensity=0.3
```

## Integração de Biomas

Os biomas são integrados nos mapas através de "camadas de pintura" que definem onde cada bioma aparece. Estas camadas são armazenadas como mapas de peso (weightmaps) que controlam a mistura entre diferentes biomas.

### Exemplo de Weightmap
- **Formato**: RAW 8-bit ou PNG grayscale
- **Resolução**: Mesma do heightmap ou metade
- **Valores**: 0 (ausente) a 255 (totalmente presente)

## Configuração de Terreno

O arquivo TerrainSettings.ini define parâmetros globais para todos os terrenos:

```ini
[TerrainGlobalSettings]
MaxHeight=1024.0
MinHeight=0.0
HeightScale=1.0
TesselationFactor=1.0
CollisionComplexity=2
LODDistanceFactor=1.0

[TerrainRenderSettings]
MaxLOD=4
MinLOD=0
LODTransitionDistance=100.0
DetailTextureDistance=1000.0
```

## Configuração do Mundo

O arquivo WorldSettings.ini define parâmetros globais para o mundo do jogo:

```ini
[WorldSettings]
WorldName=Aethelgard
WorldScale=1.0
GravityZ=-980.0
DefaultGameType=Game.MMORPGGame

[ZoneSettings]
MaxZones=64
ZoneGridSize=16384.0
StreamingDistance=8192.0

[EnvironmentSettings]
DayNightCycle=True
DayLength=24.0
TimeScale=60.0
```
