import { useEffect } from 'react';
import '../styles/Classes.css';
import combatenteImage from '../assets/images/concept_art_combatente.jpg';
import arcanistaImage from '../assets/images/concept_art_arcanista.jpg';
import rangerAtiradorImage from '../assets/images/concept_art_ranger_atirador.jpg';
import suporteImage from '../assets/images/concept_art_suporte.jpg';
import artificeEngenheiroImage from '../assets/images/concept_art_artifice_engenheiro.jpg';

const Classes = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const classes = [
    {
      id: 'combatente',
      name: 'Combatente',
      image: combatenteImage,
      description: 'Os Combatentes são guerreiros de linha de frente que dominam tanto armas tradicionais quanto tecnológicas. Especialistas em combate corpo a corpo, usam armaduras pesadas e dispositivos de proteção avançados.',
      abilities: [
        'Maestria em Armas: Proficiência com espadas, machados, martelos e armas de fogo de curto alcance',
        'Resistência Aprimorada: Armaduras reforçadas com tecnologia alienígena',
        'Provocação: Capacidade de atrair a atenção dos inimigos',
        'Golpes Poderosos: Ataques devastadores que podem derrubar oponentes'
      ],
      specializations: [
        'Cavaleiro Rúnico: Foco em proteção e defesa mágica',
        'Berserker Mecânico: Foco em dano explosivo e ataques frenéticos',
        'Sentinela Tecnológica: Foco em controle de campo e táticas defensivas'
      ]
    },
    {
      id: 'arcanista',
      name: 'Arcanista',
      image: arcanistaImage,
      description: 'Os Arcanistas são mestres da magia que aprenderam a canalizar energia arcana através de dispositivos tecnológicos. Combinam feitiços tradicionais com inovações baseadas em artefatos alienígenas.',
      abilities: [
        'Canalização Arcana: Manipulação de energia mágica pura',
        'Amplificação Tecnológica: Uso de dispositivos para potencializar feitiços',
        'Conhecimento Arcano: Compreensão profunda de magia e tecnologia',
        'Manipulação Elemental: Controle sobre elementos através de magia e dispositivos'
      ],
      specializations: [
        'Technomancer: Foco em fusão de magia e tecnologia',
        'Elementalista Quântico: Foco em manipulação avançada de elementos',
        'Cronomanipulador: Foco em alteração do fluxo temporal'
      ]
    },
    {
      id: 'ranger-atirador',
      name: 'Ranger/Atirador',
      image: rangerAtiradorImage,
      description: 'Os Rangers e Atiradores são especialistas em combate à distância, usando arcos, bestas modificadas ou armas de fogo de precisão. Mestres da camuflagem e rastreamento, são letais a longas distâncias.',
      abilities: [
        'Precisão Letal: Ataques à distância com alta precisão',
        'Camuflagem Avançada: Capacidade de se esconder mesmo em campo aberto',
        'Rastreamento: Habilidade de seguir rastros e detectar inimigos',
        'Tiro Modificado: Projéteis especiais com efeitos diversos'
      ],
      specializations: [
        'Atirador de Elite: Foco em dano massivo a alvos únicos',
        'Ranger Selvagem: Foco em sobrevivência e controle de campo',
        'Gunslinger: Foco em armas de fogo e mobilidade'
      ]
    },
    {
      id: 'suporte',
      name: 'Suporte',
      image: suporteImage,
      description: 'Os Suportes são curandeiros, protetores e potencializadores que usam magia restaurativa e dispositivos médicos avançados. Essenciais em qualquer grupo, podem salvar vidas e fortalecer aliados.',
      abilities: [
        'Cura Híbrida: Combinação de magia curativa e tecnologia médica',
        'Proteção: Escudos mágicos e barreiras tecnológicas',
        'Potencialização: Melhorias temporárias para aliados',
        'Ressurreição: Capacidade de trazer aliados caídos de volta à batalha'
      ],
      specializations: [
        'Médico de Campo: Foco em cura e remoção de efeitos negativos',
        'Guardião Arcano: Foco em proteção e escudos',
        'Bardo Tecnológico: Foco em buffs e potencializações'
      ]
    },
    {
      id: 'artifice-engenheiro',
      name: 'Artífice/Engenheiro',
      image: artificeEngenheiroImage,
      description: 'Os Artífices e Engenheiros são mestres na criação e manipulação de dispositivos. Podem construir torretas, golens, armadilhas e uma variedade de gadgets para controlar o campo de batalha.',
      abilities: [
        'Construção Rápida: Capacidade de criar dispositivos em combate',
        'Reparo: Restauração de estruturas e dispositivos danificados',
        'Sabotagem: Desativação de mecanismos inimigos',
        'Aprimoramento: Melhoria de equipamentos e armas'
      ],
      specializations: [
        'Construtor de Golens: Foco em criar assistentes de combate',
        'Demolidor: Foco em explosivos e dano em área',
        'Tecno-Alquimista: Foco em poções e elixires aprimorados'
      ]
    }
  ];

  return (
    <div className="classes">
      <div className="classes-hero">
        <div className="classes-hero-content">
          <h1>Classes de Aethelgard</h1>
          <p>Descubra os arquétipos que definem o combate neste mundo de magia e tecnologia</p>
        </div>
      </div>

      <div className="classes-content">
        <div className="container">
          <div className="classes-intro">
            <p>
              Em Aethelgard, os aventureiros se especializam em cinco arquétipos principais de classes, 
              cada um com suas próprias habilidades únicas e especializações. A fusão de magia tradicional 
              e tecnologia alienígena criou estilos de combate nunca antes vistos em mundos de fantasia.
            </p>
          </div>

          {classes.map((classItem) => (
            <div key={classItem.id} className="class-card" id={classItem.id}>
              <div className="class-image">
                <img src={classItem.image} alt={classItem.name} />
              </div>
              <div className="class-info">
                <h2>{classItem.name}</h2>
                <p className="class-description">{classItem.description}</p>
                <div className="class-abilities">
                  <h3>Habilidades Principais</h3>
                  <ul>
                    {classItem.abilities.map((ability, index) => (
                      <li key={index}>{ability}</li>
                    ))}
                  </ul>
                </div>
                <div className="class-specializations">
                  <h3>Especializações</h3>
                  <ul>
                    {classItem.specializations.map((spec, index) => (
                      <li key={index}>{spec}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Classes;
