import { useEffect } from 'react';
import '../styles/Items.css';

const Items = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const itemGrades = [
    {
      grade: 'D',
      title: 'Comum',
      description: 'Itens básicos, facilmente encontrados e fabricados. Representam tecnologia e magia rudimentares.',
      visual: 'Aparência simples, sem ornamentos. Armas e armaduras de metal comum ou madeira com, no máximo, pequenos componentes tecnológicos básicos.',
      examples: [
        'Espada de Ferro Comum',
        'Pistola de Pólvora Básica',
        'Armadura de Couro Reforçado',
        'Poção de Cura Menor'
      ],
      acquisition: 'Disponíveis em qualquer comerciante, podem ser fabricados por artesãos iniciantes ou encontrados em inimigos comuns.'
    },
    {
      grade: 'C',
      title: 'Incomum',
      description: 'Itens de qualidade superior, com melhor acabamento e materiais mais resistentes. Começam a apresentar propriedades mágicas ou tecnológicas mais evidentes.',
      visual: 'Design mais elaborado, com alguns detalhes decorativos. Armas com gravuras simples, armaduras com placas metálicas adicionais ou pequenos dispositivos tecnológicos visíveis.',
      examples: [
        'Lâmina Rúnica Menor',
        'Revólver de Precisão',
        'Armadura de Placas Reforçada',
        'Amuleto de Proteção Básico'
      ],
      acquisition: 'Vendidos por comerciantes especializados em cidades maiores, fabricados por artesãos experientes ou encontrados como recompensas de missões secundárias.'
    },
    {
      grade: 'B',
      title: 'Raro',
      description: 'Itens de excelente qualidade, com propriedades mágicas ou tecnológicas significativas. Oferecem vantagens claras em combate ou utilidade.',
      visual: 'Design sofisticado com ornamentos notáveis. Armas com runas brilhantes, armaduras com componentes tecnológicos integrados, dispositivos com partes móveis ou luzes.',
      examples: [
        'Espada de Energia Arcana',
        'Rifle de Precisão Aprimorado',
        'Armadura Tecno-Rúnica',
        'Dispositivo de Cura Avançado'
      ],
      acquisition: 'Disponíveis apenas em lojas especializadas de grandes cidades, criados por mestres artesãos ou obtidos como recompensas de missões principais e chefes de dungeons médias.'
    },
    {
      grade: 'A',
      title: 'Muito Raro',
      description: 'Itens excepcionais, com propriedades mágicas ou tecnológicas poderosas. Frequentemente possuem habilidades especiais ativáveis ou passivas significativas.',
      visual: 'Design único e impressionante. Armas com efeitos visuais constantes (chamas, eletricidade), armaduras com componentes móveis ou projeções holográficas, acessórios com gemas ou núcleos de energia pulsantes.',
      examples: [
        'Lâmina do Crepúsculo Estelar',
        'Canhão de Mão Arcanotec',
        'Armadura de Placas do Núcleo Profundo',
        'Amuleto de Distorção Temporal'
      ],
      acquisition: 'Raramente disponíveis para compra, geralmente obtidos como recompensas de missões épicas, chefes de dungeons difíceis ou eventos especiais.'
    },
    {
      grade: 'S',
      title: 'Lendário',
      description: 'Itens de poder extraordinário, frequentemente com história própria e reconhecidos em todo o mundo. Possuem múltiplas habilidades especiais e estatísticas excepcionais.',
      visual: 'Design espetacular e único. Armas com transformações ou formas alternativas, armaduras que parecem vivas ou com consciência própria, acessórios com efeitos visuais impressionantes que alteram a aparência do usuário.',
      examples: [
        'Excalibur Tecnológica',
        'Devastador Estelar de Ghalia',
        'Armadura do Conquistador Dimensional',
        'Coração da Estrela Errante'
      ],
      acquisition: 'Nunca vendidos, obtidos apenas através de missões épicas de longa duração, raids de alto nível, ou eventos mundiais raros.'
    },
    {
      grade: 'SS',
      title: 'Mítico',
      description: 'Itens de poder transcendental, capazes de alterar o equilíbrio de poder no mundo. Extremamente raros, são objetos de desejo de reis e imperadores.',
      visual: 'Design transcendental que desafia a compreensão. Armas que parecem feitas de luz, energia pura ou materiais impossíveis, armaduras que se fundem com o usuário, acessórios que distorcem a realidade ao redor.',
      examples: [
        'Lâmina do Firmamento Despedaçado',
        'Aniquilador de Mundos',
        'Armadura do Avatar Celestial',
        'Núcleo da Estrela Primordial'
      ],
      acquisition: 'Quase míticos, obtidos apenas através das mais difíceis conquistas do jogo, como derrotar chefes mundiais, completar as mais desafiadoras raids ou eventos únicos no servidor.'
    }
  ];

  return (
    <div className="items">
      <div className="items-hero">
        <div className="items-hero-content">
          <h1>Sistema de Itens</h1>
          <p>Descubra o poder dos artefatos e tecnologias de Aethelgard</p>
        </div>
      </div>

      <div className="items-content">
        <div className="container">
          <div className="items-intro">
            <p>
              Em Aethelgard, os itens são classificados em seis grades de raridade, de D (mais comum) 
              até SS (mais raro e poderoso). Esta classificação reflete não apenas o poder do item, 
              mas também sua raridade, complexidade visual e dificuldade de obtenção.
            </p>
            <p>
              A fusão única de magia tradicional e tecnologia alienígena criou possibilidades 
              ilimitadas para armas, armaduras e acessórios, desde simples espadas com melhorias 
              tecnológicas até artefatos míticos capazes de alterar a realidade.
            </p>
          </div>

          <div className="grade-table">
            <div className="grade-header">
              <div className="grade-cell">Grade</div>
              <div className="grade-cell">Raridade</div>
              <div className="grade-cell">Descrição</div>
            </div>
            
            {itemGrades.map((grade) => (
              <div key={grade.grade} className={`grade-row grade-${grade.grade.toLowerCase()}`}>
                <div className="grade-cell grade-letter">{grade.grade}</div>
                <div className="grade-cell grade-title">{grade.title}</div>
                <div className="grade-cell grade-description">{grade.description}</div>
              </div>
            ))}
          </div>

          {itemGrades.map((grade) => (
            <div key={grade.grade} className={`item-grade-section grade-${grade.grade.toLowerCase()}-section`}>
              <h2>Grade {grade.grade}: {grade.title}</h2>
              
              <div className="item-grade-details">
                <div className="item-detail">
                  <h3>Aparência</h3>
                  <p>{grade.visual}</p>
                </div>
                
                <div className="item-detail">
                  <h3>Exemplos</h3>
                  <ul>
                    {grade.examples.map((example, index) => (
                      <li key={index}>{example}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="item-detail">
                  <h3>Como Obter</h3>
                  <p>{grade.acquisition}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Items;
