import { useEffect, useState } from 'react';
import '../styles/Gallery.css';

// Importando todas as imagens
import aethelgardianImage from '../assets/images/concept_art_aethelgardian.jpg';
import sylvanElfImage from '../assets/images/concept_art_sylvan_elf.jpg';
import umbralTechnocratImage from '../assets/images/concept_art_umbral_technocrat.jpg';
import ironhideOrcImage from '../assets/images/concept_art_ironhide_orc.jpg';
import deepcoreEngineerImage from '../assets/images/concept_art_deepcore_engineer.jpg';
import combatenteImage from '../assets/images/concept_art_combatente.jpg';
import arcanistaImage from '../assets/images/concept_art_arcanista.jpg';
import rangerAtiradorImage from '../assets/images/concept_art_ranger_atirador.jpg';
import suporteImage from '../assets/images/concept_art_suporte.jpg';
import artificeEngenheiroImage from '../assets/images/concept_art_artifice_engenheiro.jpg';
import facebookCoverImage from '../assets/images/facebook_cover_aethelgard.jpg';
import facebookCoverV2Image from '../assets/images/facebook_cover_aethelgard_v2.jpg';
import facebookProfileImage from '../assets/images/facebook_profile_aethelgard.jpg';

// Definindo a interface para os itens da galeria
interface GalleryItem {
  id: number;
  image: string;
  title: string;
  category: string;
  description: string;
}

const Gallery = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);
  const [filter, setFilter] = useState('all');

  const galleryItems: GalleryItem[] = [
    {
      id: 1,
      image: aethelgardianImage,
      title: 'Aethelgardian (Humano)',
      category: 'races',
      description: 'Arte conceitual de um Aethelgardian, a raça humana de Aethelgard que encontrou equilíbrio entre tradição e inovação.'
    },
    {
      id: 2,
      image: sylvanElfImage,
      title: 'Sylvan Elf',
      category: 'races',
      description: 'Arte conceitual de um Sylvan Elf, que rejeitou a tecnologia em favor da magia natural e tradições ancestrais.'
    },
    {
      id: 3,
      image: umbralTechnocratImage,
      title: 'Umbral Technocrat (Elfo Negro)',
      category: 'races',
      description: 'Arte conceitual de um Umbral Technocrat, mestre na fusão de magia e tecnologia alienígena.'
    },
    {
      id: 4,
      image: ironhideOrcImage,
      title: 'Ironhide Orc',
      category: 'races',
      description: 'Arte conceitual de um Ironhide Orc, guerreiro formidável que adaptou a tecnologia alienígena para fins bélicos.'
    },
    {
      id: 5,
      image: deepcoreEngineerImage,
      title: 'Deepcore Engineer (Anão)',
      category: 'races',
      description: 'Arte conceitual de um Deepcore Engineer, artífice supremo que combina conhecimento ancestral de runas com tecnologia avançada.'
    },
    {
      id: 6,
      image: combatenteImage,
      title: 'Combatente',
      category: 'classes',
      description: 'Arte conceitual de um Combatente, guerreiro de linha de frente que domina tanto armas tradicionais quanto tecnológicas.'
    },
    {
      id: 7,
      image: arcanistaImage,
      title: 'Arcanista',
      category: 'classes',
      description: 'Arte conceitual de um Arcanista, mestre da magia que aprendeu a canalizar energia arcana através de dispositivos tecnológicos.'
    },
    {
      id: 8,
      image: rangerAtiradorImage,
      title: 'Ranger/Atirador',
      category: 'classes',
      description: 'Arte conceitual de um Ranger/Atirador, especialista em combate à distância usando armas de precisão.'
    },
    {
      id: 9,
      image: suporteImage,
      title: 'Suporte',
      category: 'classes',
      description: 'Arte conceitual de um Suporte, curandeiro e protetor que usa magia restaurativa e dispositivos médicos avançados.'
    },
    {
      id: 10,
      image: artificeEngenheiroImage,
      title: 'Artífice/Engenheiro',
      category: 'classes',
      description: 'Arte conceitual de um Artífice/Engenheiro, mestre na criação e manipulação de dispositivos tecnológicos e mágicos.'
    },
    {
      id: 11,
      image: facebookCoverImage,
      title: 'Paisagem de Aethelgard',
      category: 'world',
      description: 'Vista panorâmica do mundo de Aethelgard, mostrando a fusão entre elementos medievais e tecnologia alienígena.'
    },
    {
      id: 12,
      image: facebookCoverV2Image,
      title: 'Ghalia, a Cidade de Ferro',
      category: 'world',
      description: 'Vista da cidade de Ghalia, construída nas bordas de uma cratera onde uma Estrela Errante se enterrou profundamente no solo.'
    },
    {
      id: 13,
      image: facebookProfileImage,
      title: 'Engenheiro com Visor Tecnológico',
      category: 'world',
      description: 'Close-up de um personagem usando equipamento tecnológico avançado, simbolizando a fusão entre o medieval e o futurista.'
    }
  ];

  const filteredItems = filter === 'all' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === filter);

  const openLightbox = (item: GalleryItem) => {
    setSelectedImage(item);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <div className="gallery">
      <div className="gallery-hero">
        <div className="gallery-hero-content">
          <h1>Galeria de Arte</h1>
          <p>Explore as artes conceituais do universo de Aethelgard: Iron Scars</p>
        </div>
      </div>

      <div className="gallery-content">
        <div className="container">
          <div className="gallery-filters">
            <button 
              className={filter === 'all' ? 'active' : ''} 
              onClick={() => setFilter('all')}
            >
              Todos
            </button>
            <button 
              className={filter === 'races' ? 'active' : ''} 
              onClick={() => setFilter('races')}
            >
              Raças
            </button>
            <button 
              className={filter === 'classes' ? 'active' : ''} 
              onClick={() => setFilter('classes')}
            >
              Classes
            </button>
            <button 
              className={filter === 'world' ? 'active' : ''} 
              onClick={() => setFilter('world')}
            >
              Mundo
            </button>
          </div>

          <div className="gallery-grid">
            {filteredItems.map((item) => (
              <div 
                key={item.id} 
                className="gallery-item"
                onClick={() => openLightbox(item)}
              >
                <div className="gallery-item-image">
                  <img src={item.image} alt={item.title} />
                </div>
                <div className="gallery-item-overlay">
                  <h3>{item.title}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {selectedImage && (
        <div className="lightbox" onClick={closeLightbox}>
          <div className="lightbox-content" onClick={(e) => e.stopPropagation()}>
            <span className="close-button" onClick={closeLightbox}>&times;</span>
            <img src={selectedImage.image} alt={selectedImage.title} />
            <div className="lightbox-caption">
              <h3>{selectedImage.title}</h3>
              <p>{selectedImage.description}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Gallery;
