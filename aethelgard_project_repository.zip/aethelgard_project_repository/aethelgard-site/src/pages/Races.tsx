import { useEffect } from 'react';
import '../styles/Races.css';
import aethelgardianImage from '../assets/images/concept_art_aethelgardian.jpg';
import sylvanElfImage from '../assets/images/concept_art_sylvan_elf.jpg';
import umbralTechnocratImage from '../assets/images/concept_art_umbral_technocrat.jpg';
import ironhideOrcImage from '../assets/images/concept_art_ironhide_orc.jpg';
import deepcoreEngineerImage from '../assets/images/concept_art_deepcore_engineer.jpg';

const Races = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const races = [
    {
      id: 'aethelgardian',
      name: 'Aethelgardian (Humano)',
      image: aethelgardianImage,
      description: 'Os Aethelgardianos são humanos adaptáveis que encontraram um equilíbrio entre tradição e inovação. Após a Queda, dividiram-se entre tradicionalistas e progressistas, mas sua capacidade de adaptação permitiu que prosperassem neste novo mundo.',
      traits: [
        'Adaptabilidade: Aprendem novas habilidades com facilidade',
        'Versatilidade: Podem se especializar em qualquer classe',
        'Diplomacia: Mantêm relações com todas as outras raças',
        'Inovação: Combinam magia tradicional com tecnologia recuperada'
      ],
      homeland: 'Cidades-estado espalhadas por planícies e vales, com Ghalia, a Cidade de Ferro, sendo seu maior assentamento.'
    },
    {
      id: 'sylvan-elf',
      name: 'Sylvan Elf',
      image: sylvanElfImage,
      description: 'Os Elfos Sylvan rejeitaram a tecnologia das Estrelas Errantes, considerando-a uma corrupção do mundo natural. Isolaram-se em suas florestas ancestrais, aprimorando sua conexão com a magia natural e defendendo ferozmente seus territórios.',
      traits: [
        'Afinidade Natural: Conexão profunda com a magia elemental',
        'Longevidade: Vidas que duram séculos',
        'Tradicionalistas: Rejeitam tecnologia em favor da magia pura',
        'Arqueiros Excepcionais: Mestres do arco longo e da camuflagem'
      ],
      homeland: 'Florestas antigas, especialmente a Floresta de Verdant Reach, onde cidades arbóreas se escondem entre árvores milenares.'
    },
    {
      id: 'umbral-technocrat',
      name: 'Umbral Technocrat (Elfo Negro)',
      image: umbralTechnocratImage,
      description: 'Os Tecnocratas Umbrais foram os primeiros a dominar a fusão entre magia e tecnologia. Vivendo em cidades subterrâneas, estudam obsessivamente os artefatos das Estrelas Errantes, criando dispositivos híbridos alimentados por energia arcana.',
      traits: [
        'Tecnomagia: Mestres na fusão de magia e tecnologia',
        'Visão no Escuro: Adaptados à vida subterrânea',
        'Intelectuais: Valorizam conhecimento e inovação',
        'Pragmáticos: Usam qualquer meio para alcançar seus objetivos'
      ],
      homeland: 'Cidades subterrâneas construídas em cavernas expansivas, com Shadowforge sendo a maior metrópole tecnocrata.'
    },
    {
      id: 'ironhide-orc',
      name: 'Ironhide Orc',
      image: ironhideOrcImage,
      description: 'Os Orcs Pele-de-Ferro adaptaram a tecnologia alienígena para criar armas brutais e eficientes. Organizados em clãs militarizados, são guerreiros formidáveis que valorizam força e honra acima de tudo.',
      traits: [
        'Força Bruta: Fisicamente os mais poderosos',
        'Resistência: Pele espessa que oferece proteção natural',
        'Engenhosidade Prática: Adaptam tecnologia para fins bélicos',
        'Código de Honra: Seguem tradições de combate rigorosas'
      ],
      homeland: 'Fortalezas nas terras altas e montanhas, com a Cidadela de Iron Fist sendo seu maior bastião.'
    },
    {
      id: 'deepcore-engineer',
      name: 'Deepcore Engineer (Anão)',
      image: deepcoreEngineerImage,
      description: 'Os Engenheiros do Núcleo Profundo aplicaram seu conhecimento ancestral de metalurgia e runas para aprimorar os artefatos alienígenas. São os melhores artífices do mundo, criando armas, armaduras e dispositivos de incrível poder.',
      traits: [
        'Artífices Supremos: Inigualáveis na criação de itens',
        'Resistência à Magia: Naturalmente resistentes a efeitos arcanos',
        'Tenacidade: Determinação inabalável',
        'Conhecimento Técnico: Compreensão profunda de mecânica e engenharia'
      ],
      homeland: 'Cidades-fortaleza escavadas dentro de montanhas, com Deepforge sendo o centro de sua civilização.'
    }
  ];

  return (
    <div className="races">
      <div className="races-hero">
        <div className="races-hero-content">
          <h1>Raças de Aethelgard</h1>
          <p>Conheça os povos que disputam o controle deste mundo devastado</p>
        </div>
      </div>

      <div className="races-content">
        <div className="container">
          <div className="races-intro">
            <p>
              Cinco raças principais habitam o mundo de Aethelgard, cada uma com sua própria relação 
              com a magia tradicional e a tecnologia alienígena trazida pelas Estrelas Errantes. 
              Suas diferenças culturais, físicas e filosóficas moldam suas sociedades e seu papel 
              no equilíbrio de poder do mundo.
            </p>
          </div>

          {races.map((race) => (
            <div key={race.id} className="race-card" id={race.id}>
              <div className="race-image">
                <img src={race.image} alt={race.name} />
              </div>
              <div className="race-info">
                <h2>{race.name}</h2>
                <p className="race-description">{race.description}</p>
                <div className="race-traits">
                  <h3>Características</h3>
                  <ul>
                    {race.traits.map((trait, index) => (
                      <li key={index}>{trait}</li>
                    ))}
                  </ul>
                </div>
                <div className="race-homeland">
                  <h3>Terra Natal</h3>
                  <p>{race.homeland}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Races;
