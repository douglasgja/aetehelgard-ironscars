import { useEffect } from 'react';
import '../styles/Lore.css';
import loreImage from '../assets/images/facebook_cover_aethelgard_v2.jpg';

const Lore = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="lore">
      <div className="lore-hero" style={{ backgroundImage: `url(${loreImage})` }}>
        <div className="lore-hero-content">
          <h1>A História de Aethelgard</h1>
          <p>As Cicatrizes do Firmamento e o Trovão de Ferro</p>
        </div>
      </div>

      <div className="lore-content">
        <div className="container">
          <div className="lore-section">
            <h2>As Cicatrizes do Firmamento</h2>
            <p>
              Por milênios, Aethelgard foi um mundo de magia clássica, onde elfos, humanos, anões e orcs 
              viviam em um equilíbrio tenso, com reinos medievais disputando territórios e recursos. A magia 
              fluía naturalmente pelo mundo, canalizada por aqueles com talento e estudo.
            </p>
            <p>
              Tudo mudou quando o céu se rompeu. Em uma noite que ficou conhecida como "A Queda", objetos 
              gigantescos e metálicos - que os estudiosos chamaram de "Estrelas Errantes" - rasgaram o 
              firmamento e se chocaram contra o planeta. Não eram estrelas, mas sim fragmentos de uma 
              civilização tecnologicamente avançada de outro mundo ou dimensão.
            </p>
            <p>
              Os impactos devastaram regiões inteiras, alteraram o fluxo de magia e deixaram cicatrizes 
              permanentes na paisagem. Mas o verdadeiro legado da Queda foram os artefatos e tecnologias 
              alienígenas espalhados pelo mundo.
            </p>
          </div>

          <div className="lore-section">
            <h2>O Trovão de Ferro</h2>
            <p>
              Nos dois séculos seguintes à Queda, Aethelgard passou por uma transformação radical. As 
              primeiras armas de fogo, criadas a partir de tecnologia recuperada, foram chamadas de 
              "Trovões de Ferro" - dispositivos ruidosos e primitivos que, no entanto, mudaram para 
              sempre a natureza dos conflitos.
            </p>
            <p>
              Enquanto algumas raças abraçaram a nova tecnologia, outras a rejeitaram. Os Sylvan Elves 
              se isolaram em suas florestas ancestrais, aprimorando sua magia natural. Os Umbral Technocrats 
              (Elfos Negros) foram os primeiros a dominar a fusão entre magia e tecnologia, criando 
              dispositivos híbridos alimentados por energia arcana.
            </p>
            <p>
              Os Deepcore Engineers (Anões) aplicaram seu conhecimento de metalurgia para aprimorar os 
              artefatos alienígenas, enquanto os Ironhide Orcs adaptaram a tecnologia para criar armas 
              brutais e eficientes. Os Aethelgardians (Humanos) se dividiram entre tradicionalistas e 
              progressistas, alguns mantendo-se fiéis às antigas tradições, outros abraçando o novo mundo.
            </p>
          </div>

          <div className="lore-section">
            <h2>O Mundo Atual</h2>
            <p>
              Hoje, Aethelgard é um mundo onde castelos medievais são protegidos por canhões rúnicos, 
              onde cavaleiros em armaduras encantadas empunham pistolas ao lado de espadas, e onde magos 
              estudam tanto grimórios antigos quanto fragmentos de tecnologia alienígena.
            </p>
            <p>
              As grandes cidades cresceram em torno dos locais de impacto mais significativos, como 
              Ghalia, a Cidade de Ferro, construída nas bordas de uma cratera onde uma Estrela Errante 
              particularmente grande se enterrou profundamente no solo.
            </p>
            <p>
              Os reinos e facções disputam não apenas territórios e recursos tradicionais, mas também 
              os preciosos fragmentos tecnológicos das Estrelas Errantes. Expedições são enviadas 
              regularmente para explorar novas crateras ou ruínas recém-descobertas, em busca de 
              artefatos que possam dar vantagem nas guerras constantes.
            </p>
            <p>
              E há rumores inquietantes: alguns dizem que as Estrelas Errantes não eram apenas naves 
              ou estações, mas contêineres... e que algo veio com elas. Nas profundezas de algumas 
              crateras, exploradores relatam estruturas que parecem estar se reconstruindo lentamente, 
              e máquinas que operam sozinhas, seguindo propósitos incompreensíveis.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Lore;
