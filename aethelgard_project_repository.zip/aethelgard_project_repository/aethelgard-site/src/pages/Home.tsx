import { Link } from 'react-router-dom';
import '../styles/Home.css';
import heroImage from '../assets/images/facebook_cover_aethelgard.jpg';
import aethelgardianImage from '../assets/images/concept_art_aethelgardian.jpg';
import umbralTechnocratImage from '../assets/images/concept_art_umbral_technocrat.jpg';
import ironhideOrcImage from '../assets/images/concept_art_ironhide_orc.jpg';

const Home = () => {
  return (
    <div className="home">
      <div className="hero-container" style={{ backgroundImage: `url(${heroImage})` }}>
        <h1>AETHELGARD: IRON SCARS</h1>
        <p>Um MMORPG épico onde fantasia colide com tecnologia!</p>
        <div className="hero-btns">
          <Link to="/lore" className="btn-primary">
            Conheça o Universo
          </Link>
        </div>
      </div>

      <div className="home-intro">
        <div className="container">
          <h2>Bem-vindo a Aethelgard</h2>
          <p>
            Em um mundo marcado por estrelas caídas, use magia e tecnologia para lutar pelo poder, 
            dominar a economia e conquistar castelos com seu clã. A guerra começou!
          </p>
        </div>
      </div>

      <div className="cards-section">
        <div className="container">
          <h2>Explore o Jogo</h2>
          <div className="cards-container">
            <div className="card">
              <img src={umbralTechnocratImage} alt="Lore" />
              <div className="card-info">
                <h3>Lore</h3>
                <p>Descubra a história de um mundo devastado pelas Cicatrizes do Firmamento.</p>
                <Link to="/lore" className="btn-secondary">
                  Explorar
                </Link>
              </div>
            </div>
            <div className="card">
              <img src={aethelgardianImage} alt="Raças" />
              <div className="card-info">
                <h3>Raças</h3>
                <p>Conheça as cinco raças que lutam pela supremacia em Aethelgard.</p>
                <Link to="/races" className="btn-secondary">
                  Explorar
                </Link>
              </div>
            </div>
            <div className="card">
              <img src={ironhideOrcImage} alt="Classes" />
              <div className="card-info">
                <h3>Classes</h3>
                <p>Descubra os arquétipos de classes e suas habilidades únicas.</p>
                <Link to="/classes" className="btn-secondary">
                  Explorar
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="cta-section">
        <div className="container">
          <h2>Prepare-se para a Batalha</h2>
          <p>
            Escolha sua raça, especialize sua classe, domine a economia, conquiste castelos com seu clã 
            e deixe sua marca neste universo implacável.
          </p>
          <Link to="/gallery" className="btn-primary">
            Ver Galeria
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
