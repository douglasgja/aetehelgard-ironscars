import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Lore from './pages/Lore';
import Races from './pages/Races';
import Classes from './pages/Classes';
import Items from './pages/Items';
import Gallery from './pages/Gallery';
import './App.css';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/lore" element={<Lore />} />
        <Route path="/races" element={<Races />} />
        <Route path="/classes" element={<Classes />} />
        <Route path="/items" element={<Items />} />
        <Route path="/gallery" element={<Gallery />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
