import { useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles/Navbar.css';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          Aethelgard: Iron Scars
        </Link>
        
        <div className="menu-icon" onClick={toggleMenu}>
          <i className={isOpen ? 'fas fa-times' : 'fas fa-bars'}></i>
        </div>
        
        <ul className={isOpen ? 'nav-menu active' : 'nav-menu'}>
          <li className="nav-item">
            <Link to="/" className="nav-links" onClick={toggleMenu}>
              Home
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/lore" className="nav-links" onClick={toggleMenu}>
              Lore
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/races" className="nav-links" onClick={toggleMenu}>
              Raças
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/classes" className="nav-links" onClick={toggleMenu}>
              Classes
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/items" className="nav-links" onClick={toggleMenu}>
              Itens
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/gallery" className="nav-links" onClick={toggleMenu}>
              Galeria
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
