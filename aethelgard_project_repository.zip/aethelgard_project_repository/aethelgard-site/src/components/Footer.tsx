import { Link } from 'react-router-dom';
import '../styles/Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-links">
          <div className="footer-link-wrapper">
            <div className="footer-link-items">
              <h2>Navegação</h2>
              <Link to="/">Home</Link>
              <Link to="/lore">Lore</Link>
              <Link to="/races">Raças</Link>
              <Link to="/classes">Classes</Link>
              <Link to="/items">Itens</Link>
              <Link to="/gallery">Galeria</Link>
            </div>
          </div>
        </div>
        <section className="social-media">
          <div className="social-media-wrap">
            <div className="footer-logo">
              <Link to="/" className="social-logo">
                Aethelgard: Iron Scars
              </Link>
            </div>
            <small className="website-rights">© {new Date().getFullYear()} Aethelgard: Iron Scars. Todos os direitos reservados.</small>
            <div className="social-icons">
              <a
                className="social-icon-link facebook"
                href="#"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
              >
                <i className="fab fa-facebook-f" />
              </a>
            </div>
          </div>
        </section>
      </div>
    </footer>
  );
};

export default Footer;
