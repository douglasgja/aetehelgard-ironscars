# Biografia para Página do Facebook - Aethelgard: Iron Scars

**Opção Curta (Máx. 255 caracteres):**

Aethelgard: Iron Scars - MMORPG épico onde fantasia colide com tecnologia! ⚔️⚙️ Em um mundo marcado por estrelas caídas, use magia e tecnologia para lutar pelo poder, dominar a economia e conquistar castelos com seu clã. A guerra começou! #AethelgardIronScars

**Opção Longa (Original):**

Bem-vindo à página oficial de Aethelgard: Iron Scars! ⚔️⚙️ Mergulhe em um MMORPG épico onde a fantasia clássica colide com tecnologia perdida. No mundo devastado de Aethelgard, marcado pelas cicatrizes de estrelas caídas, facções lutam pelo poder usando magia ancestral e tecnologia recuperada. Escolha sua raça, especialize sua classe, domine a economia, conquiste castelos com seu clã e deixe sua marca neste universo implacável. A guerra pela supremacia começou! Junte-se à batalha.

**Hashtags Sugeridos:**
#AethelgardIronScars #MMORPG #Fantasia #SciFi #PvP #Siege #RPG #Lançamento #Gaming

**Observações:**
*   Considere fixar um post com mais detalhes sobre o jogo ou um link para um site/discord (quando disponível).
*   Use as artes de capa e perfil que criamos para complementar a página.

