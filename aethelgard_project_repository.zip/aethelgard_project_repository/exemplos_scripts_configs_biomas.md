# Exemplos de Scripts e Configurações para Biomas e Terrenos

## Exemplo de Script TerrainInfo.uc

```
class AethelgardTerrainInfo extends TerrainInfo;

// Constantes para tipos de bioma
const BIOME_FOREST = 0;
const BIOME_MOUNTAIN = 1;
const BIOME_DESERT = 2;
const BIOME_SWAMP = 3;
const BIOME_CRATER = 4;
const BIOME_RUINS = 5;

// Mapeamento de biomas para texturas
var array<Material> BiomeBaseMaterials;
var array<Material> BiomeDetailMaterials;
var array<Texture> BiomeNormalMaps;

// Mapeamento de biomas para vegetação
var array<StaticMesh> BiomeTrees;
var array<StaticMesh> BiomeBushes;
var array<StaticMesh> BiomeRocks;

// Configurações de densidade de vegetação por bioma
var array<float> TreeDensity;
var array<float> BushDensity;
var array<float> GrassDensity;

// Mapa de biomas (weightmap)
var Texture BiomeWeightMap;

// Inicialização
function PostBeginPlay()
{
    Super.PostBeginPlay();
    LoadBiomeSettings();
    ApplyBiomeTextures();
    SpawnVegetation();
}

// Carrega configurações de bioma dos arquivos .ini
function LoadBiomeSettings()
{
    local int i;
    local string BiomeName;
    local string ConfigPath;
    
    for (i = 0; i < 6; i++)
    {
        switch(i)
        {
            case BIOME_FOREST:
                BiomeName = "Forest";
                break;
            case BIOME_MOUNTAIN:
                BiomeName = "Mountain";
                break;
            case BIOME_DESERT:
                BiomeName = "Desert";
                break;
            case BIOME_SWAMP:
                BiomeName = "Swamp";
                break;
            case BIOME_CRATER:
                BiomeName = "Crater";
                break;
            case BIOME_RUINS:
                BiomeName = "Ruins";
                break;
        }
        
        ConfigPath = "Config/Biomes/" $ BiomeName $ ".ini";
        
        // Carregar texturas
        BiomeBaseMaterials[i] = Material(DynamicLoadObject(GetConfigString(ConfigPath, "TerrainSettings", "BaseTexture"), class'Material'));
        BiomeDetailMaterials[i] = Material(DynamicLoadObject(GetConfigString(ConfigPath, "TerrainSettings", "DetailTexture"), class'Material'));
        BiomeNormalMaps[i] = Texture(DynamicLoadObject(GetConfigString(ConfigPath, "TerrainSettings", "NormalMap"), class'Texture'));
        
        // Carregar densidades
        TreeDensity[i] = GetConfigFloat(ConfigPath, "VegetationSettings", "TreeDensity");
        BushDensity[i] = GetConfigFloat(ConfigPath, "VegetationSettings", "BushDensity");
        GrassDensity[i] = GetConfigFloat(ConfigPath, "VegetationSettings", "GrassDensity");
        
        // Carregar vegetação
        LoadVegetationTypes(i, ConfigPath);
    }
}

// Carrega tipos de vegetação para um bioma específico
function LoadVegetationTypes(int BiomeIndex, string ConfigPath)
{
    local string TreeList, BushList;
    local array<string> Trees, Bushes;
    local int i;
    
    TreeList = GetConfigString(ConfigPath, "VegetationSettings", "TreeTypes");
    BushList = GetConfigString(ConfigPath, "VegetationSettings", "BushTypes");
    
    // Dividir as strings em arrays
    Split(TreeList, ",", Trees);
    Split(BushList, ",", Bushes);
    
    // Carregar árvores
    for (i = 0; i < Trees.Length; i++)
    {
        BiomeTrees[BiomeIndex * 10 + i] = StaticMesh(DynamicLoadObject(Trees[i], class'StaticMesh'));
    }
    
    // Carregar arbustos
    for (i = 0; i < Bushes.Length; i++)
    {
        BiomeBushes[BiomeIndex * 10 + i] = StaticMesh(DynamicLoadObject(Bushes[i], class'StaticMesh'));
    }
}

// Aplica texturas de bioma ao terreno
function ApplyBiomeTextures()
{
    local int i;
    
    for (i = 0; i < TerrainSectors.Length; i++)
    {
        // Determinar bioma predominante para este setor
        // (Simplificado - na implementação real, usaria o weightmap)
        TerrainSectors[i].SectorMaterial = BiomeBaseMaterials[GetPredominantBiome(i)];
    }
}

// Determina o bioma predominante para um setor
function int GetPredominantBiome(int SectorIndex)
{
    // Implementação simplificada - na versão real, analisaria o weightmap
    // para determinar o bioma predominante neste setor
    return SectorIndex % 6; // Alterna entre os 6 tipos de bioma
}

// Gera vegetação com base nos biomas
function SpawnVegetation()
{
    local int x, y, BiomeType;
    local vector Position;
    local rotator Rotation;
    local float Density, RandVal;
    local StaticMesh MeshToSpawn;
    
    // Percorrer o terreno em uma grade
    for (x = 0; x < TerrainWidth; x += 512)
    {
        for (y = 0; y < TerrainHeight; y += 512)
        {
            Position.X = x;
            Position.Y = y;
            Position.Z = GetTerrainHeight(x, y);
            
            // Determinar bioma neste ponto
            BiomeType = GetBiomeAtLocation(Position);
            
            // Tentar gerar árvore
            Density = TreeDensity[BiomeType];
            RandVal = FRand(); // Valor aleatório entre 0 e 1
            
            if (RandVal < Density)
            {
                // Escolher árvore aleatória para este bioma
                MeshToSpawn = GetRandomTree(BiomeType);
                
                // Rotação aleatória
                Rotation.Yaw = Rand(65536);
                
                // Gerar árvore
                if (MeshToSpawn != None)
                {
                    Spawn(class'StaticMeshActor', self, , Position, Rotation, MeshToSpawn);
                }
            }
            
            // Processo similar para arbustos e rochas...
        }
    }
}

// Retorna uma árvore aleatória para o bioma especificado
function StaticMesh GetRandomTree(int BiomeType)
{
    local int BaseIndex, RandomOffset;
    
    BaseIndex = BiomeType * 10; // Cada bioma tem até 10 tipos de árvores
    RandomOffset = Rand(Min(10, CountNonNullTrees(BiomeType)));
    
    return BiomeTrees[BaseIndex + RandomOffset];
}

// Conta quantos tipos de árvores não-nulas existem para um bioma
function int CountNonNullTrees(int BiomeType)
{
    local int i, Count, BaseIndex;
    
    Count = 0;
    BaseIndex = BiomeType * 10;
    
    for (i = 0; i < 10; i++)
    {
        if (BiomeTrees[BaseIndex + i] != None)
        {
            Count++;
        }
    }
    
    return Count;
}

// Determina o bioma em uma localização específica
function int GetBiomeAtLocation(vector Location)
{
    // Na implementação real, usaria o weightmap para determinar o bioma
    // Esta é uma versão simplificada baseada na posição
    
    // Dividir o mapa em regiões
    if (Location.X < TerrainWidth * 0.33)
    {
        if (Location.Y < TerrainHeight * 0.5)
            return BIOME_FOREST;
        else
            return BIOME_SWAMP;
    }
    else if (Location.X < TerrainWidth * 0.66)
    {
        if (Location.Y < TerrainHeight * 0.5)
            return BIOME_MOUNTAIN;
        else
            return BIOME_RUINS;
    }
    else
    {
        if (Location.Y < TerrainHeight * 0.5)
            return BIOME_DESERT;
        else
            return BIOME_CRATER;
    }
}

// Funções auxiliares para ler configurações
function string GetConfigString(string FilePath, string Section, string Key)
{
    // Implementação simplificada - na versão real, leria do arquivo .ini
    return "DefaultValue";
}

function float GetConfigFloat(string FilePath, string Section, string Key)
{
    // Implementação simplificada - na versão real, leria do arquivo .ini
    return 0.5; // Valor padrão
}

defaultproperties
{
    // Inicialização de arrays
    Begin Object Class=TerrainMaterial Name=ForestMaterial
        // Configurações do material de floresta
    End Object
    BiomeBaseMaterials(0)=ForestMaterial
    
    // Outras inicializações...
}
```

## Exemplo de Script BiomeManager.uc

```
class BiomeManager extends Actor;

// Referência ao TerrainInfo
var AethelgardTerrainInfo Terrain;

// Efeitos ambientais por bioma
var array<Sound> BiomeAmbientSounds;
var array<ParticleSystem> BiomeParticleEffects;
var array<Color> BiomeLightColors;
var array<Color> BiomeFogColors;
var array<float> BiomeFogDensities;

// Inicialização
function PostBeginPlay()
{
    Super.PostBeginPlay();
    
    // Encontrar o TerrainInfo
    foreach AllActors(class'AethelgardTerrainInfo', Terrain)
    {
        break;
    }
    
    if (Terrain == None)
    {
        Log("BiomeManager: Não foi possível encontrar AethelgardTerrainInfo!");
        return;
    }
    
    LoadBiomeEnvironmentSettings();
    SetupEnvironmentalEffects();
}

// Carrega configurações ambientais dos biomas
function LoadBiomeEnvironmentSettings()
{
    local int i;
    local string BiomeName;
    local string ConfigPath;
    
    for (i = 0; i < 6; i++)
    {
        switch(i)
        {
            case 0: BiomeName = "Forest"; break;
            case 1: BiomeName = "Mountain"; break;
            case 2: BiomeName = "Desert"; break;
            case 3: BiomeName = "Swamp"; break;
            case 4: BiomeName = "Crater"; break;
            case 5: BiomeName = "Ruins"; break;
        }
        
        ConfigPath = "Config/Biomes/" $ BiomeName $ ".ini";
        
        // Carregar sons ambientais
        BiomeAmbientSounds[i] = Sound(DynamicLoadObject(GetConfigString(ConfigPath, "EnvironmentSettings", "AmbientSound"), class'Sound'));
        
        // Carregar efeitos de partículas
        BiomeParticleEffects[i] = ParticleSystem(DynamicLoadObject(GetConfigString(ConfigPath, "EnvironmentSettings", "ParticleEffect"), class'ParticleSystem'));
        
        // Carregar cores de luz e névoa
        BiomeLightColors[i] = ParseColor(GetConfigString(ConfigPath, "EnvironmentSettings", "LightColor"));
        BiomeFogColors[i] = ParseColor(GetConfigString(ConfigPath, "EnvironmentSettings", "FogColor"));
        
        // Carregar densidade de névoa
        BiomeFogDensities[i] = GetConfigFloat(ConfigPath, "EnvironmentSettings", "FogDensity");
    }
}

// Configura efeitos ambientais
function SetupEnvironmentalEffects()
{
    // Configurar sons ambientais
    SetupAmbientSounds();
    
    // Configurar efeitos de partículas
    SetupParticleEffects();
    
    // Configurar iluminação e névoa
    SetupLightingAndFog();
}

// Configura sons ambientais
function SetupAmbientSounds()
{
    local int i;
    local vector Location;
    local int BiomeType;
    
    // Colocar emissores de som em pontos estratégicos do mapa
    for (i = 0; i < 20; i++)
    {
        // Escolher localização aleatória
        Location.X = FRand() * Terrain.TerrainWidth;
        Location.Y = FRand() * Terrain.TerrainHeight;
        Location.Z = Terrain.GetTerrainHeight(Location.X, Location.Y) + 100;
        
        // Determinar bioma neste ponto
        BiomeType = Terrain.GetBiomeAtLocation(Location);
        
        // Criar emissor de som
        if (BiomeAmbientSounds[BiomeType] != None)
        {
            SpawnAmbientSoundEmitter(Location, BiomeAmbientSounds[BiomeType]);
        }
    }
}

// Gera um emissor de som ambiente
function SpawnAmbientSoundEmitter(vector Location, Sound AmbientSound)
{
    local AmbientSoundActor SoundEmitter;
    
    SoundEmitter = Spawn(class'AmbientSoundActor', self, , Location);
    if (SoundEmitter != None)
    {
        SoundEmitter.AmbientSound = AmbientSound;
        SoundEmitter.SoundRadius = 2000;
        SoundEmitter.SoundVolume = 128;
    }
}

// Configura efeitos de partículas
function SetupParticleEffects()
{
    local int i;
    local vector Location;
    local int BiomeType;
    
    // Colocar emissores de partículas em pontos estratégicos do mapa
    for (i = 0; i < 30; i++)
    {
        // Escolher localização aleatória
        Location.X = FRand() * Terrain.TerrainWidth;
        Location.Y = FRand() * Terrain.TerrainHeight;
        Location.Z = Terrain.GetTerrainHeight(Location.X, Location.Y) + 50;
        
        // Determinar bioma neste ponto
        BiomeType = Terrain.GetBiomeAtLocation(Location);
        
        // Criar emissor de partículas
        if (BiomeParticleEffects[BiomeType] != None)
        {
            SpawnParticleEmitter(Location, BiomeParticleEffects[BiomeType]);
        }
    }
}

// Gera um emissor de partículas
function SpawnParticleEmitter(vector Location, ParticleSystem ParticleEffect)
{
    local ParticleSystemComponent PSC;
    
    PSC = new(self) class'ParticleSystemComponent';
    PSC.SetTemplate(ParticleEffect);
    PSC.SetAbsolute(true, true, true);
    PSC.SetTranslation(Location);
    PSC.SetActive(true);
    AttachComponent(PSC);
}

// Configura iluminação e névoa
function SetupLightingAndFog()
{
    local int i;
    local vector Location;
    local int BiomeType;
    local ZoneInfo Zone;
    
    // Encontrar todas as ZoneInfo e configurar com base no bioma predominante
    foreach AllActors(class'ZoneInfo', Zone)
    {
        Location = Zone.Location;
        BiomeType = Terrain.GetBiomeAtLocation(Location);
        
        // Configurar névoa
        Zone.FogColor = BiomeFogColors[BiomeType];
        Zone.FogDensity = BiomeFogDensities[BiomeType];
        
        // Configurar iluminação ambiente
        Zone.AmbientBrightness = 32;
        Zone.AmbientHue = GetHueFromColor(BiomeLightColors[BiomeType]);
        Zone.AmbientSaturation = GetSaturationFromColor(BiomeLightColors[BiomeType]);
    }
}

// Funções auxiliares para cores
function Color ParseColor(string ColorString)
{
    local Color Result;
    local array<string> Components;
    
    // Formato esperado: "(R=120,G=140,B=100)"
    // Remover parênteses
    ColorString = Mid(ColorString, 1, Len(ColorString) - 2);
    
    // Dividir por vírgulas
    Split(ColorString, ",", Components);
    
    // Extrair componentes
    Result.R = int(Mid(Components[0], 2));
    Result.G = int(Mid(Components[1], 2));
    Result.B = int(Mid(Components[2], 2));
    Result.A = 255;
    
    return Result;
}

function byte GetHueFromColor(Color C)
{
    // Implementação simplificada - na versão real, calcularia o matiz
    return (C.R + C.G + C.B) / 3;
}

function byte GetSaturationFromColor(Color C)
{
    // Implementação simplificada - na versão real, calcularia a saturação
    return 128;
}

// Funções auxiliares para ler configurações
function string GetConfigString(string FilePath, string Section, string Key)
{
    // Implementação simplificada - na versão real, leria do arquivo .ini
    return "DefaultValue";
}

function float GetConfigFloat(string FilePath, string Section, string Key)
{
    // Implementação simplificada - na versão real, leria do arquivo .ini
    return 0.5; // Valor padrão
}

defaultproperties
{
    // Inicialização de arrays
    BiomeAmbientSounds(0)=Sound'Sounds.Environment.ForestAmbience'
    BiomeAmbientSounds(1)=Sound'Sounds.Environment.MountainWind'
    BiomeAmbientSounds(2)=Sound'Sounds.Environment.DesertWind'
    BiomeAmbientSounds(3)=Sound'Sounds.Environment.SwampAmbience'
    BiomeAmbientSounds(4)=Sound'Sounds.Environment.CraterAmbience'
    BiomeAmbientSounds(5)=Sound'Sounds.Environment.RuinsAmbience'
    
    // Outras inicializações...
}
```

## Exemplos de Arquivos de Configuração de Biomas

### Forest.ini
```ini
[BiomeSettings]
Name=Forest
Description=Floresta densa com vegetação abundante e árvores altas

[TerrainSettings]
BaseTexture=TerrainTextures.Forest.Base
DetailTexture=DetailTextures.Forest.Detail
NormalMap=TerrainTextures.Forest.Normal
TextureScale=8.0
DetailScale=16.0
HeightScale=1.0
MaxHeight=512.0
MinHeight=0.0

[VegetationSettings]
TreeDensity=0.8
GrassDensity=0.9
BushDensity=0.7
TreeTypes=ForestTrees.Oak,ForestTrees.Pine,ForestTrees.Maple,ForestTrees.Birch
GrassTypes=ForestGrass.Tall,ForestGrass.Short,ForestGrass.Fern
BushTypes=ForestBushes.Berry,ForestBushes.Fern,ForestBushes.Shrub

[EnvironmentSettings]
AmbientSound=Sounds.Environment.ForestAmbience
ParticleEffect=ParticleEffects.Forest.LeafParticles
WeatherTypes=Weather.Rain,Weather.Fog,Weather.LightBreeze
LightColor=(R=120,G=140,B=100)
FogColor=(R=180,G=200,B=180)
FogDensity=0.3
WindStrength=0.4
```

### Mountain.ini
```ini
[BiomeSettings]
Name=Mountain
Description=Terreno rochoso e elevado com pouca vegetação

[TerrainSettings]
BaseTexture=TerrainTextures.Mountain.Base
DetailTexture=DetailTextures.Mountain.Detail
NormalMap=TerrainTextures.Mountain.Normal
TextureScale=12.0
DetailScale=24.0
HeightScale=1.5
MaxHeight=1024.0
MinHeight=256.0

[VegetationSettings]
TreeDensity=0.2
GrassDensity=0.3
BushDensity=0.1
TreeTypes=MountainTrees.Pine,MountainTrees.Spruce
GrassTypes=MountainGrass.Alpine,MountainGrass.Sparse
BushTypes=MountainBushes.Rocky,MountainBushes.Thistle

[EnvironmentSettings]
AmbientSound=Sounds.Environment.MountainWind
ParticleEffect=ParticleEffects.Mountain.SnowParticles
WeatherTypes=Weather.Snow,Weather.StrongWind,Weather.Blizzard
LightColor=(R=150,G=150,B=170)
FogColor=(R=200,G=200,B=220)
FogDensity=0.5
WindStrength=0.8
```

### Desert.ini
```ini
[BiomeSettings]
Name=Desert
Description=Terreno árido com dunas de areia e pouca vegetação

[TerrainSettings]
BaseTexture=TerrainTextures.Desert.Base
DetailTexture=DetailTextures.Desert.Detail
NormalMap=TerrainTextures.Desert.Normal
TextureScale=16.0
DetailScale=32.0
HeightScale=0.8
MaxHeight=384.0
MinHeight=0.0

[VegetationSettings]
TreeDensity=0.05
GrassDensity=0.1
BushDensity=0.15
TreeTypes=DesertTrees.Palm,DesertTrees.Cactus
GrassTypes=DesertGrass.Dry,DesertGrass.Tumbleweed
BushTypes=DesertBushes.Cactus,DesertBushes.DeadBush

[EnvironmentSettings]
AmbientSound=Sounds.Environment.DesertWind
ParticleEffect=ParticleEffects.Desert.SandParticles
WeatherTypes=Weather.SandStorm,Weather.HeatHaze
LightColor=(R=180,G=160,B=120)
FogColor=(R=220,G=200,B=160)
FogDensity=0.2
WindStrength=0.6
```

### Swamp.ini
```ini
[BiomeSettings]
Name=Swamp
Description=Terreno pantanoso com água rasa e vegetação densa

[TerrainSettings]
BaseTexture=TerrainTextures.Swamp.Base
DetailTexture=DetailTextures.Swamp.Detail
NormalMap=TerrainTextures.Swamp.Normal
TextureScale=8.0
DetailScale=16.0
HeightScale=0.5
MaxHeight=128.0
MinHeight=-32.0

[VegetationSettings]
TreeDensity=0.4
GrassDensity=0.7
BushDensity=0.6
TreeTypes=SwampTrees.Willow,SwampTrees.Cypress,SwampTrees.Mangrove
GrassTypes=SwampGrass.Reeds,SwampGrass.Cattail
BushTypes=SwampBushes.Moss,SwampBushes.Fern,SwampBushes.Mushroom

[EnvironmentSettings]
AmbientSound=Sounds.Environment.SwampAmbience
ParticleEffect=ParticleEffects.Swamp.MistParticles
WeatherTypes=Weather.Fog,Weather.LightRain
LightColor=(R=100,G=120,B=100)
FogColor=(R=150,G=170,B=150)
FogDensity=0.7
WindStrength=0.2
```

### Crater.ini
```ini
[BiomeSettings]
Name=Crater
Description=Terreno devastado por impacto de Estrela Errante, com tecnologia alienígena

[TerrainSettings]
BaseTexture=TerrainTextures.Crater.Base
DetailTexture=DetailTextures.Crater.Detail
NormalMap=TerrainTextures.Crater.Normal
TextureScale=10.0
DetailScale=20.0
HeightScale=1.2
MaxHeight=256.0
MinHeight=-128.0

[VegetationSettings]
TreeDensity=0.0
GrassDensity=0.1
BushDensity=0.05
TreeTypes=CraterTrees.DeadTree
GrassTypes=CraterGrass.Ash,CraterGrass.Glowing
BushTypes=CraterBushes.Crystalline,CraterBushes.AlienGrowth

[EnvironmentSettings]
AmbientSound=Sounds.Environment.CraterAmbience
ParticleEffect=ParticleEffects.Crater.EnergyParticles
WeatherTypes=Weather.EnergyStorm,Weather.AshFall
LightColor=(R=120,G=100,B=180)
FogColor=(R=140,G=120,B=200)
FogDensity=0.4
WindStrength=0.3
```

### Ruins.ini
```ini
[BiomeSettings]
Name=Ruins
Description=Ruínas de civilização antiga com estruturas deterioradas

[TerrainSettings]
BaseTexture=TerrainTextures.Ruins.Base
DetailTexture=DetailTextures.Ruins.Detail
NormalMap=TerrainTextures.Ruins.Normal
TextureScale=8.0
DetailScale=16.0
HeightScale=1.0
MaxHeight=384.0
MinHeight=0.0

[VegetationSettings]
TreeDensity=0.2
GrassDensity=0.5
BushDensity=0.4
TreeTypes=RuinsTrees.DeadOak,RuinsTrees.Overgrown
GrassTypes=RuinsGrass.Overgrown,RuinsGrass.Moss
BushTypes=RuinsBushes.Ivy,RuinsBushes.Moss,RuinsBushes.Shrub

[EnvironmentSettings]
AmbientSound=Sounds.Environment.RuinsAmbience
ParticleEffect=ParticleEffects.Ruins.DustParticles
WeatherTypes=Weather.LightRain,Weather.Fog
LightColor=(R=130,G=130,B=150)
FogColor=(R=170,G=170,B=190)
FogDensity=0.4
WindStrength=0.3
```

## Exemplo de Arquivo TerrainSettings.ini

```ini
[TerrainGlobalSettings]
MaxHeight=1024.0
MinHeight=-128.0
HeightScale=1.0
TesselationFactor=1.0
CollisionComplexity=2
LODDistanceFactor=1.0
DefaultTerrainMaterial=TerrainTextures.Default.Base
DefaultDetailMaterial=DetailTextures.Default.Detail

[TerrainRenderSettings]
MaxLOD=4
MinLOD=0
LODTransitionDistance=100.0
DetailTextureDistance=1000.0
MaxDrawDistance=16384.0
MinDrawDistance=100.0
OcclusionDistance=2000.0
TerrainSectorSize=512.0

[TerrainPhysicsSettings]
FrictionFactor=1.0
RestitutionFactor=0.3
TerrainCollisionDetail=16
EnableTerrainPhysics=True

[TerrainDecorationSettings]
MaxDecorationsPerSector=100
DecorationDrawDistance=2000.0
DecorationFadeDistance=1500.0
DecorationDensityScale=1.0
EnableDynamicShadows=True
```

## Exemplo de Arquivo WorldSettings.ini

```ini
[WorldSettings]
WorldName=Aethelgard
WorldScale=1.0
GravityZ=-980.0
DefaultGameType=Game.MMORPGGame
WorldTimeScale=1.0
EnableDayNightCycle=True
DayLength=24.0
TimeScale=60.0

[ZoneSettings]
MaxZones=64
ZoneGridSize=16384.0
StreamingDistance=8192.0
MaxVisibleZones=8
ZoneLoadingPriority=2
EnableZoneStreaming=True

[EnvironmentSettings]
GlobalWindDirection=(X=1.0,Y=1.0,Z=0.0)
GlobalWindStrength=0.5
GlobalAmbientColor=(R=128,G=128,B=128)
GlobalSunColor=(R=255,G=240,B=210)
GlobalMoonColor=(R=150,G=160,B=200)
WeatherChangeInterval=1800.0
WeatherTransitionTime=300.0

[PlayerSettings]
MaxPlayers=2000
MaxPlayersPerZone=200
PlayerCollisionRadius=34.0
PlayerCollisionHeight=78.0
PlayerMeshScale=1.0
DefaultPlayerSpeed=440.0
DefaultJumpZ=420.0
```

## Exemplo de Heightmap

Para criar um heightmap para o terreno, você precisará de uma imagem em escala de cinza com as seguintes características:

1. **Formato**: RAW 16-bit (recomendado para UE 2.5)
2. **Resolução**: 513x513 (2^n + 1)
3. **Profundidade de cor**: 16 bits por pixel
4. **Valores**:
   - Preto (0): Altitude mínima
   - Branco (65535): Altitude máxima
   - Cinza médio (32768): Altitude média

Você pode criar heightmaps usando ferramentas como:
- World Machine
- Terragen
- L3DT
- GIMP ou Photoshop (para heightmaps mais simples)

## Exemplo de Weightmap

Para definir a transição entre biomas, você precisará de weightmaps para cada tipo de bioma:

1. **Formato**: RAW 8-bit ou PNG grayscale
2. **Resolução**: Mesma do heightmap ou metade (257x257)
3. **Profundidade de cor**: 8 bits por pixel
4. **Valores**:
   - Preto (0): Bioma ausente neste ponto
   - Branco (255): Bioma totalmente presente
   - Tons de cinza: Mistura entre biomas

Cada bioma terá seu próprio weightmap, e a soma dos valores em cada ponto deve ser aproximadamente 255 para garantir uma cobertura completa.
