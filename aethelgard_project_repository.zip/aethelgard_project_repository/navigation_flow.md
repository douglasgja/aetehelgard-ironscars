# Fluxo de Navegação - Aethelgard: Iron Scars

## Estrutura de Navegação Principal

### Menu Superior
- **Posicionamento**: Fixo no topo da página
- **Itens**: Home, Lore, Raças, Classes, Itens, Galeria
- **Comportamento**: Destacar item atual, colapsar em menu hambúrguer em dispositivos móveis
- **Logo**: Ao clicar no logo, retorna à página inicial

### Fluxo de Navegação Primário
1. **Entrada no Site**: Usuário chega à página inicial
2. **Exploração Guiada**: 
   - CTA principal na hero section leva à seção de Lore
   - Cards de destaque na home levam às seções principais

### Fluxo de Navegação Secundário
- **Navegação Contextual**: Links internos nas seções que conectam conteúdos relacionados
  - Ex: Na seção de Raças, links para Classes relacionadas
  - Ex: Na seção de Lore, links para Raças mencionadas

### Navegação Interna nas Seções
- **Raças e Classes**: Tabs ou carrossel para alternar entre diferentes opções
- **Galeria**: Grid com opção de filtro por categoria (Raças, Classes, Mundo)
- **Sistema de Itens**: Tabs para alternar entre diferentes grades

## Mapa do Site Detalhado

```
Home
│
├── Lore
│   ├── Introdução
│   ├── As Cicatrizes do Firmamento
│   ├── O Mundo de Aethelgard
│   └── Conflito Central
│
├── Raças
│   ├── Aethelgardian (Humano)
│   ├── Sylvan Elf
│   ├── Umbral Technocrat (Elfo Negro)
│   ├── Ironhide Orc
│   └── Deepcore Engineer (Anão)
│
├── Classes
│   ├── Combatente
│   ├── Arcanista
│   ├── Ranger/Atirador
│   ├── Suporte
│   └── Artífice/Engenheiro
│
├── Sistema de Itens
│   ├── Introdução ao Sistema
│   ├── Grades de Itens (D-SS)
│   ├── Exemplos de Itens
│   └── Mecânicas de Obtenção
│
└── Galeria
    ├── Raças
    ├── Classes
    └── Mundo
```

## Elementos de Navegação Específicos

### Breadcrumbs
- Presente em todas as páginas exceto Home
- Formato: Home > [Seção Atual] > [Subseção, se aplicável]

### Links "Saiba Mais"
- Ao final de cada seção, sugestões de próximas seções a explorar
- Ex: Ao final da seção Raças: "Conheça as Classes disponíveis para cada Raça"

### Footer
- Links para todas as seções principais
- Botão "Voltar ao Topo"

## Interações e Transições

### Transições entre Páginas
- Fade suave entre seções principais
- Scroll suave para navegação interna

### Elementos Interativos
- Cards com hover effect
- Imagens com zoom ao clicar
- Tabs com indicação visual clara da seleção atual

## Responsividade

### Desktop
- Menu completo visível
- Layout em grid ou colunas múltiplas

### Tablet
- Menu completo visível ou colapsado dependendo do espaço
- Layout adaptado para menos colunas

### Mobile
- Menu hambúrguer
- Layout em coluna única
- Carrosséis para conteúdos em cards
