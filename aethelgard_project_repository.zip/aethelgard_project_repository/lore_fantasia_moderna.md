# Lore Preliminar: As Cicatrizes do Firmamento e o Trovão de Ferro

## Prólogo: A Queda das Estrelas Errantes

Nos anais mais antigos do mundo de Aethelgard, antes mesmo que os Elfos registrassem as primeiras canções sob as árvores ancestrais e os Anões escavassem os corações das montanhas primordiais, houve um tempo de relativa paz mágica. Os deuses caminhavam entre os mortais, a mana fluía como rios invisíveis e os conflitos, embora existentes, eram travados com a fúria das garras, o fio do aço encantado e o poder arcano bruto. As grandes raças – Humanos, Elfos, Elfos Negros, Orcs e Anões – disputavam terras e poder sob os olhares atentos das divindades e dos dragões ancestrais.

Mas essa era terminou em uma noite de fogo e presságios. O evento, conhecido em fragmentos de textos sobreviventes como "A Queda das Estrelas Errantes" ou "O Rasgo no Firmamento", não foi uma chuva de meteoros comum. Rasgos luminosos cortaram a tapeçaria do céu noturno, e deles caíram não pedras celestiais, mas fragmentos de um outro lugar, um mundo alienígena de metal, vidro e energias desconhecidas. Estruturas colossais, máquinas quebradas e artefatos incompreensíveis choveram sobre Aethelgard, alguns se desintegrando na atmosfera mágica, outros cravando-se profundamente na terra como cicatrizes permanentes.

O impacto foi cataclísmico. Ondas de choque varreram continentes, a própria mana do mundo foi perturbada, causando tempestades arcanas e mutações em criaturas. Civilizações antigas ruíram, engolidas pela terra ou incineradas pela energia liberada. Por séculos, as áreas de impacto permaneceram como zonas proibidas, envoltas em lendas sobre maldições, monstros metálicos e tesouros mortais. A magia levou tempo para se estabilizar, e as raças sobreviventes reconstruíram suas sociedades sobre as ruínas, lembrando a Queda apenas como um mito sombrio, uma ira divina inexplicável.

## O Despertar do Metal e a Era do Trovão de Ferro

Milênios se passaram. As raças de Aethelgard floresceram novamente, redescobrindo magias perdidas e forjando novos impérios. Os locais da Queda, embora ainda perigosos e repletos de anomalias, começaram a ser explorados por aventureiros ousados e, mais significativamente, pelos Anões e por uma facção humana emergente conhecida como os Artífices de Ghalia.

Os Anões, com sua afinidade inata por metais e mecanismos, foram os primeiros a realmente decifrar alguns dos segredos dos destroços. Eles descobriram ligas metálicas desconhecidas, fontes de energia compactas e, crucialmente, os princípios por trás de um pó negro explosivo e dos mecanismos que o utilizavam para propelir projéteis metálicos a velocidades aterradoras. Inicialmente, criaram ferramentas de mineração mais eficientes e canhões rudimentares para defender suas fortalezas subterrâneas. O conhecimento, no entanto, era difícil de conter.

Os Artífices de Ghalia, uma guilda humana que misturava alquimia, engenharia e uma dose de pragmatismo implacável, roubaram ou compraram os segredos dos Anões. Eles rapidamente refinaram os projetos, criando as primeiras armas de fogo portáteis – arcabuzes barulhentos, pistolas de pederneira instáveis, mas inegavelmente eficazes. Nascia o "Trovão de Ferro".

## A Grande Cisma: Magia vs. Máquina

A proliferação das armas de fogo causou uma cisma profunda nas sociedades de Aethelgard. Os reinos élficos, guardiões das tradições arcanas, viram a tecnologia como uma abominação – barulhenta, suja e desprovida da elegância e do poder da magia. Eles redobraram seus estudos arcanos, buscando magias defensivas contra projéteis e formas de neutralizar os mecanismos profanos. Muitos Elfos Negros, sempre buscando poder por qualquer meio, viram potencial na nova tecnologia, adaptando-a com seus próprios encantamentos sombrios, criando armas que disparavam projéteis amaldiçoados ou imbuídos de energia negra.

Os Orcs, inicialmente desdenhosos, logo perceberam a força bruta do Trovão de Ferro. Seus ferreiros começaram a criar versões maiores, mais brutas e frequentemente mais perigosas para o próprio usuário, valorizando o poder destrutivo acima da precisão ou segurança. Canhões de mão orcs e bacamartes explosivos tornaram-se visões comuns em seus bandos de guerra.

Os Humanos ficaram divididos. Reinos tradicionais, liderados por cavaleiros e magos de batalha, tentaram proibir ou limitar o uso das armas de fogo, vendo-as como uma ameaça à ordem estabelecida e à nobreza do combate corpo a corpo. No entanto, nações mercantis, guildas de artífices e exércitos que buscavam uma vantagem rápida abraçaram a tecnologia. Surgiram novas classes de guerreiros: os Mosqueteiros, os Engenheiros de Cerco, os Pistoleiros.

Os Anões, embora pioneiros, adotaram uma postura mais cautelosa, focando em armas de cerco massivas e armaduras capazes de resistir aos projéteis, além de continuarem a aprimorar suas próprias armas de fogo com precisão e confiabilidade incomparáveis, muitas vezes combinando-as com runas de poder.

## O Mundo Atual: Uma Mistura Instável

Hoje, Aethelgard é um mundo onde a magia ancestral coexiste desconfortavelmente com a tecnologia emergente. Cavaleiros em armaduras rúnicas podem ser alvejados por franco-atiradores escondidos. Magos conjuram barreiras de energia para deter saraivadas de balas, enquanto engenheiros posicionam torretas automáticas para defender muralhas de castelos. As ruínas da Queda ainda guardam segredos tecnológicos e perigos imensuráveis, atraindo aventureiros em busca de poder ou conhecimento proibido.

O sistema de clãs e a política de dominação territorial foram profundamente afetados. Sieges agora envolvem tanto aríetes encantados e bolas de fogo quanto canhões e cargas de demolição. Clãs podem se especializar em táticas mágicas, poder de fogo tecnológico ou uma combinação híbrida. A economia viu o surgimento de novos recursos (pólvora, metais especiais, peças de máquinas) e novas profissões (armeiros, engenheiros).

Os jogadores entram neste mundo em um momento de tensão crescente. Antigas profecias falam de um novo cataclismo, talvez ligado à tecnologia das Estrelas Errantes. Facções lutam pelo controle dos recursos tecnológicos e mágicos. E nas profundezas das ruínas esquecidas, algo antigo e alienígena pode estar despertando, atraído pelo eco familiar do Trovão de Ferro...

Esta fusão cria um cenário único onde fantasia clássica e elementos modernos colidem, oferecendo uma vasta gama de possibilidades para classes, combate, exploração e conflitos de larga escala.
