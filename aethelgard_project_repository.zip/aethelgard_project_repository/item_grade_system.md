# Sistema de Grade de Itens: Aethelgard (D a SS)

Este documento detalha o sistema de classificação (Grade) para equipamentos (armas, armaduras, acessórios) no MMORPG Aethelgard, que varia de D (mais comum e fraco) a SS (extremamente raro e poderoso). Este sistema visa fornecer uma progressão clara para os jogadores, indicar a raridade e o poder relativo dos itens, e integrar-se à lore que mistura fantasia e tecnologia.

## Visão Geral das Grades

O sistema utiliza seis grades principais:

1.  **Grade D:** Comum / Básico
2.  **Grade C:** Incomum / Padrão
3.  **Grade B:** Raro / Avançado
4.  **Grade A:** Épico / Superior
5.  **Grade S:** Lendário / Obra-Prima
6.  **Grade SS:** Mítico / Artefato

Cada grade representa um salto significativo em atributos base, número de bônus adicionais, potencial de encantamento, complexidade visual e raridade.

## Detalhamento por Grade

**Grade D (Comum / Básico)**

*   **Poder:** Atributos muito básicos, geralmente sem bônus adicionais significativos. Servem como equipamento inicial ou temporário.
*   **Raridade:** Muito comum. Facilmente obtido de monstros de nível baixo, vendedores NPC básicos, ou crafting inicial.
*   **Visual:** Design simples, funcional, muitas vezes desgastado ou de fabricação em massa. Poucos ou nenhuns efeitos visuais. Em termos de tecnologia, seriam peças rudimentares, talvez enferrujadas ou de ligas simples. Armas de fogo seriam modelos de pederneira básicos e pouco confiáveis.
*   **Obtenção:** Drops de monstros comuns (níveis 1-20), quests iniciais, crafting básico com materiais abundantes, vendedores NPC em vilas.
*   **Economia:** Valor de mercado muito baixo, geralmente vendidos para NPCs por pouco dinheiro.

**Grade C (Incomum / Padrão)**

*   **Poder:** Atributos modestos, podem ter um ou dois bônus adicionais simples (ex: +HP, +MP, +Ataque leve). Equipamento padrão para jogadores em níveis intermediários baixos.
*   **Raridade:** Incomum. Encontrado com mais frequência que D, mas ainda relativamente fácil de obter.
*   **Visual:** Design mais refinado que o D, mas ainda funcional. Pode ter pequenos detalhes ou emblemas. Armas podem ter um brilho sutil. Equipamentos tecnológicos podem parecer mais bem montados, mas ainda utilitários. Armas de fogo podem ser arcabuzes ou pistolas mais padronizadas.
*   **Obtenção:** Drops de monstros de nível intermediário-baixo (níveis 20-40), recompensas de quests, crafting com materiais um pouco mais raros, alguns vendedores especializados.
*   **Economia:** Valor de mercado moderado, podem ser comercializados entre jogadores iniciantes.

**Grade B (Raro / Avançado)**

*   **Poder:** Atributos bons, geralmente com múltiplos bônus adicionais ou um bônus mais significativo (ex: +Chance de Crítico, +Velocidade de Ataque, Resistência Elemental). Equipamento sólido para a maior parte do conteúdo de nível intermediário.
*   **Raridade:** Raro. Requer mais esforço para obter.
*   **Visual:** Design distinto, com detalhes mais elaborados, materiais de melhor qualidade visível. Armas podem ter um brilho mais pronunciado ou efeitos visuais sutis (ex: leve fumaça, faíscas). Equipamentos tecnológicos começam a mostrar sinais de engenharia avançada (engrenagens visíveis, luzes fracas). Armas de fogo podem ser mosquetes bem trabalhados ou pistolas com mecanismos mais complexos.
*   **Obtenção:** Drops de monstros mais fortes (níveis 40-60), mini-bosses, dungeons intermediárias, crafting avançado com materiais raros, recompensas de quests importantes.
*   **Economia:** Valor de mercado considerável, frequentemente comercializados entre jogadores.

**Grade A (Épico / Superior)**

*   **Poder:** Atributos excelentes, com múltiplos bônus poderosos e/ou efeitos únicos (procs, habilidades passivas). Equipamento desejado para conteúdo de nível alto e início de endgame.
*   **Raridade:** Muito raro. Difícil de obter, geralmente ligado a conteúdo desafiador.
*   **Visual:** Design impressionante e único, muitas vezes com temas específicos (élfico, anão, tecnológico). Efeitos visuais notáveis (brilho intenso, partículas, energia pulsante). Equipamentos tecnológicos parecem sofisticados, talvez com partes móveis ou displays de energia. Armas de fogo podem ser rifles de precisão, carabinas rúnicas ou armas com múltiplos canos.
*   **Obtenção:** Drops de Raid Bosses, chefes de dungeons difíceis (níveis 60+), crafting de mestre com materiais extremamente raros (talvez de origem celestial/tecnológica), recompensas de longas cadeias de quests épicas.
*   **Economia:** Valor de mercado alto, itens muito cobiçados e negociados por grandes quantias.

**Grade S (Lendário / Obra-Prima)**

*   **Poder:** Atributos excepcionais, bônus extremamente poderosos e efeitos que podem definir builds ou estratégias. Equipamento de endgame, o ápice do poder para a maioria dos jogadores.
*   **Raridade:** Extremamente raro. Obtido apenas através das atividades mais difíceis do jogo.
*   **Visual:** Design icônico e majestoso ou ameaçador. Efeitos visuais espetaculares e únicos que alteram a aparência do personagem de forma significativa. Equipamentos tecnológicos podem parecer quase alienígenas ou perfeitamente integrados com magia (runas brilhantes em circuitos). Armas de fogo podem ser canhões de mão energizados, rifles de plasma instáveis ou armas que disparam projéteis elementais/mágicos.
*   **Obtenção:** Drops de World Bosses mais poderosos, chefes finais de Raids de alta dificuldade, crafting lendário (exigindo receitas secretas, materiais únicos e talvez sorte), recompensas de conquistas monumentais.
*   **Economia:** Valor de mercado altíssimo, frequentemente ligados ao jogador (soulbound) ou negociados em mercados exclusivos por fortunas.

**Grade SS (Mítico / Artefato)**

*   **Poder:** Atributos divinos ou absurdamente altos. Efeitos únicos que podem mudar drasticamente a jogabilidade da classe ou ter impacto em larga escala (ex: buffs para todo o grupo/raid). Poder comparável aos artefatos dos deuses ou à tecnologia perdida das Estrelas Errantes.
*   **Raridade:** Quase mítica. Pouquíssimos exemplares existem no servidor, talvez únicos.
*   **Visual:** Design transcendente, inconfundível e inspirador de admiração ou terror. Efeitos visuais avassaladores que dominam a tela. Podem ser armas que parecem feitas de pura energia, armaduras que se transformam ou tecnologia alienígena incompreensível.
*   **Obtenção:** Recompensas de eventos mundiais extremamente raros e difíceis, conclusão de linhas de quests que abrangem toda a história do jogo, talvez drops únicos de chefes secretos com chance infinitesimal, ou crafting que exige a combinação de múltiplos itens Lendários e um componente mítico.
*   **Economia:** Praticamente inestimáveis. Se negociáveis, definiriam a economia. Mais provavelmente, seriam itens ligados à alma do personagem que os conquistou, símbolos de status e poder supremo.

## Progressão e Encantamento

*   Itens de grades superiores geralmente terão um potencial maior para encantamento (maior nível máximo de enchant, menor chance de falha/quebra).
*   Pode haver sistemas para tentar "promover" um item de uma grade para a próxima (ex: de A para S), mas seria um processo extremamente caro, arriscado e que exigiria materiais raríssimos.

Este sistema de grades fornece uma estrutura clara para a progressão do equipamento, alinhando poder, raridade e esforço necessário para obtê-los, ao mesmo tempo que permite incorporar a temática única de fantasia e tecnologia de Aethelgard nos visuais e nomes dos itens.
