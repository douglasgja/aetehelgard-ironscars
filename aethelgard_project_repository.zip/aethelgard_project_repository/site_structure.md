# Estrutura do Site - Aethelgard: Iron Scars

## Visão Geral
Este documento detalha a estrutura planejada para o site oficial do MMORPG "Aethelgard: Iron Scars", um jogo que mescla fantasia medieval com elementos tecnológicos.

## Seções do Site

### 1. Página Inicial (Home)
- **Hero Section**: Banner principal com a arte de capa do Facebook, logo do jogo e slogan
- **Call-to-Action**: Botão "Conheça o Universo" que leva à seção de Lore
- **Breve Introdução**: Versão curta da biografia do jogo
- **Destaques**: Cards com links para as principais seções (Lore, Raças, Classes, Itens)

### 2. Lore (História do Mundo)
- **Introdução**: Contextualização do universo
- **As Cicatrizes do Firmamento**: História sobre as estrelas caídas
- **O Mundo de Aethelgard**: Descrição das principais regiões
- **Conflito Central**: A disputa por poder e recursos
- **Imagens**: Arte conceitual que ilustre o mundo

### 3. Raças
- **Introdução**: Explicação sobre as raças jogáveis
- **Cards para cada raça**:
  - Aethelgardian (Humano)
  - Sylvan Elf
  - Umbral Technocrat (Elfo Negro)
  - Ironhide Orc
  - Deepcore Engineer (Anão)
- **Cada card contém**: Imagem da arte conceitual, nome, descrição breve e características

### 4. Classes
- **Introdução**: Explicação sobre o sistema de classes
- **Cards para cada arquétipo**:
  - Combatente
  - Arcanista
  - Ranger/Atirador
  - Suporte
  - Artífice/Engenheiro
- **Cada card contém**: Imagem da arte conceitual, nome, descrição breve e habilidades principais

### 5. Sistema de Itens
- **Introdução**: Explicação sobre o sistema de grades de itens
- **Tabela de Grades**: Detalhes sobre cada grade (D, C, B, A, S, SS)
- **Exemplos de Itens**: Imagens ou descrições de itens icônicos
- **Mecânicas**: Como obter, melhorar e comercializar itens

### 6. Galeria
- **Grid de imagens**: Todas as artes conceituais criadas
- **Visualização ampliada**: Opção para ver as imagens em tamanho maior
- **Legendas**: Descrição de cada imagem

### 7. Footer
- **Links de navegação**: Para todas as seções do site
- **Créditos**: Menção aos criadores
- **Copyright**: Informações de direitos autorais
- **Redes sociais**: Links para Facebook (quando disponível)

## Navegação
- **Menu principal**: Fixo no topo, com links para todas as seções
- **Navegação interna**: Links contextuais entre seções relacionadas
- **Responsividade**: Adaptação para dispositivos móveis com menu hambúrguer

## Estilo Visual
- **Paleta de cores**: Tons de azul, dourado e marrom escuro (baseados nas artes conceituais)
- **Tipografia**: Fontes medievais estilizadas para títulos, fontes sans-serif para corpo de texto
- **Elementos visuais**: Bordas ornamentadas, texturas de pergaminho e metal
- **Efeitos**: Transições suaves, paralaxe sutil em algumas seções

## Tecnologias
- **Framework**: React (site estático)
- **Estilização**: CSS/SCSS com possível uso de Tailwind
- **Responsividade**: Design adaptável para todos os dispositivos
- **Otimização**: Carregamento eficiente de imagens e recursos
