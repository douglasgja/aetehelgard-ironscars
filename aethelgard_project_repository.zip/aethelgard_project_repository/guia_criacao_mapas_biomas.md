# Guia de Criação e Integração de Mapas e Biomas para Aethelgard: Iron Scars

Este documento apresenta um guia passo a passo para criar e integrar mapas e biomas no MMORPG "Aethelgard: Iron Scars", utilizando a Unreal Engine 2.5, a mesma tecnologia usada no Lineage 2.

## Índice

1. [Visão Geral do Processo](#visão-geral-do-processo)
2. [Requisitos de Software](#requisitos-de-software)
3. [Criação de Heightmaps](#criação-de-heightmaps)
4. [Criação de Weightmaps para Biomas](#criação-de-weightmaps-para-biomas)
5. [Configuração de Biomas](#configuração-de-biomas)
6. [Criação de Mapas no UnrealEd](#criação-de-mapas-no-unrealed)
7. [Integração de Scripts](#integração-de-scripts)
8. [Testes e Otimização](#testes-e-otimização)
9. [Exportação e Integração Final](#exportação-e-integração-final)
10. [Solução de Problemas Comuns](#solução-de-problemas-comuns)

## Visão Geral do Processo

O processo de criação de mapas e biomas para Aethelgard: Iron Scars segue estas etapas principais:

1. Criar heightmaps para definir a topografia do terreno
2. Criar weightmaps para definir a distribuição dos biomas
3. Configurar arquivos .ini para cada bioma
4. Importar heightmaps e configurar terreno no UnrealEd
5. Aplicar texturas e configurações de bioma
6. Adicionar vegetação e elementos ambientais
7. Configurar iluminação e efeitos atmosféricos
8. Testar e otimizar o mapa
9. Exportar e integrar ao servidor de jogo

## Requisitos de Software

Para criar mapas e biomas para Aethelgard: Iron Scars, você precisará:

- **Unreal Engine 2.5 Editor (UnrealEd)** - O mesmo usado no Lineage 2
- **Editor de imagens** - GIMP, Photoshop ou similar para criar heightmaps e weightmaps
- **Software de terreno** - World Machine, Terragen ou L3DT (opcional, mas recomendado)
- **Editor de texto** - Para editar arquivos .ini e scripts .uc
- **UnrealScript Compiler** - Para compilar scripts personalizados

## Criação de Heightmaps

### O que são Heightmaps?

Heightmaps são imagens em escala de cinza que definem a elevação do terreno. Cada pixel representa um ponto no terreno, onde:
- **Preto (valor 0)**: Altitude mínima
- **Branco (valor 65535 para 16-bit)**: Altitude máxima
- **Tons de cinza**: Altitudes intermediárias

### Especificações para Unreal Engine 2.5

- **Formato**: RAW 16-bit (sem cabeçalho)
- **Resolução**: Potências de 2 + 1 (129x129, 257x257, 513x513, 1025x1025)
- **Valor médio**: 32768 (metade do intervalo de 0-65535 para uint16)

### Passo a Passo para Criar um Heightmap

#### Usando World Machine (Recomendado)

1. Abra o World Machine e crie um novo projeto
2. Defina a resolução para 513x513 (ou outra potência de 2 + 1)
3. Use geradores de terreno (Basic Perlin, Erosion, etc.) para criar a topografia
4. Ajuste a escala vertical para corresponder à escala do seu mundo
5. Exporte como RAW 16-bit

#### Usando Photoshop/GIMP

1. Crie uma nova imagem com 513x513 pixels
2. Defina o modo de cor para escala de cinza de 16 bits
3. Use pincéis, gradientes e filtros para criar a topografia
4. Salve como RAW 16-bit (sem cabeçalho)

### Dicas para Heightmaps Eficientes

- **Planeje com antecedência**: Esboce seu mapa em papel antes de começar
- **Pense em gameplay**: Crie áreas planas para cidades e áreas montanhosas para desafios
- **Evite extremos**: Evite mudanças muito abruptas de elevação
- **Considere a escala**: 1 unidade no heightmap = 1 unidade no mundo do jogo
- **Teste regularmente**: Importe no UnrealEd para verificar como está ficando

## Criação de Weightmaps para Biomas

### O que são Weightmaps?

Weightmaps são imagens em escala de cinza que definem onde cada bioma aparece no mapa. Cada bioma tem seu próprio weightmap, onde:
- **Preto (valor 0)**: Bioma ausente neste ponto
- **Branco (valor 255)**: Bioma totalmente presente
- **Tons de cinza**: Mistura parcial com outros biomas

### Especificações para Weightmaps

- **Formato**: RAW 8-bit ou PNG grayscale
- **Resolução**: Mesma do heightmap ou metade (257x257 para um heightmap de 513x513)
- **Profundidade de cor**: 8 bits por pixel

### Passo a Passo para Criar Weightmaps

1. Abra seu software de edição de imagem
2. Crie uma nova imagem com a mesma resolução do heightmap (ou metade)
3. Para cada bioma, crie uma camada separada
4. Use pincéis com bordas suaves para definir as áreas de cada bioma
5. Certifique-se de que a soma dos valores em cada ponto seja aproximadamente 255
6. Exporte cada camada como um arquivo separado em formato RAW 8-bit

### Dicas para Weightmaps Eficientes

- **Transições suaves**: Crie transições graduais entre biomas
- **Considere a topografia**: Biomas devem fazer sentido com a elevação (ex: montanhas em áreas altas)
- **Pense em ecossistemas**: Posicione biomas de forma realista (florestas perto de água, etc.)
- **Use máscaras automáticas**: Você pode gerar weightmaps baseados na elevação e inclinação

## Configuração de Biomas

### Estrutura dos Arquivos de Configuração

Cada bioma é definido por um arquivo .ini na pasta `Config/Biomes/` com seções para:
- Configurações gerais do bioma
- Configurações de terreno e texturas
- Configurações de vegetação
- Configurações ambientais

### Passo a Passo para Configurar um Bioma

1. Crie um novo arquivo .ini na pasta `Config/Biomes/` (ex: `Forest.ini`)
2. Defina as seções e parâmetros conforme os exemplos fornecidos
3. Configure as texturas base, de detalhe e mapas normais
4. Configure a densidade e tipos de vegetação
5. Configure sons ambientes, efeitos de partículas e configurações atmosféricas
6. Salve o arquivo

### Exemplo de Configuração de Bioma

```ini
[BiomeSettings]
Name=Forest
Description=Floresta densa com vegetação abundante

[TerrainSettings]
BaseTexture=TerrainTextures.Forest.Base
DetailTexture=DetailTextures.Forest.Detail
NormalMap=TerrainTextures.Forest.Normal
TextureScale=8.0
DetailScale=16.0

[VegetationSettings]
TreeDensity=0.8
GrassDensity=0.9
BushDensity=0.7
TreeTypes=ForestTrees.Oak,ForestTrees.Pine,ForestTrees.Maple
GrassTypes=ForestGrass.Tall,ForestGrass.Short
BushTypes=ForestBushes.Berry,ForestBushes.Fern

[EnvironmentSettings]
AmbientSound=Sounds.Environment.ForestAmbience
WeatherTypes=Weather.Rain,Weather.Fog
LightColor=(R=120,G=140,B=100)
FogColor=(R=180,G=200,B=180)
FogDensity=0.3
```

## Criação de Mapas no UnrealEd

### Preparação do UnrealEd

1. Inicie o UnrealEd 2.5
2. Crie um novo mapa (File > New)
3. Configure as propriedades do mapa (View > Map Properties)
   - Defina o tamanho do mapa
   - Configure a iluminação global
   - Defina o tipo de jogo

### Importação do Heightmap

1. No UnrealEd, vá para Terrain > Import Height Map
2. Navegue até o arquivo RAW do heightmap
3. Configure os parâmetros de importação:
   - Resolução (deve corresponder ao seu arquivo)
   - Escala vertical
   - Suavização (opcional)
4. Clique em "Import"

### Configuração do Terreno

1. Selecione o ator TerrainInfo no mapa
2. No painel de propriedades, configure:
   - TerrainScale (escala do terreno)
   - MaxTesselationLevel (nível de detalhe)
   - TerrainSectorSize (tamanho dos setores)
3. Configure a colisão do terreno (Collision > TerrainCollision)

### Aplicação de Texturas e Biomas

1. Importe as texturas de terreno (File > Import)
2. Crie um novo material de terreno (Right-click > New TerrainMaterial)
3. Configure o material com as texturas base e de detalhe
4. Aplique o material ao terreno (Terrain > Apply Material)
5. Importe os weightmaps para biomas (Terrain > Import Layer)
6. Configure cada camada para corresponder a um bioma

## Integração de Scripts

### Compilação de Scripts UnrealScript

1. Coloque os arquivos .uc na pasta `Scripts/Classes/`
2. Abra um prompt de comando na pasta raiz do projeto
3. Execute o compilador UnrealScript:
   ```
   ucc make
   ```
4. Verifique se não há erros de compilação

### Integração dos Scripts no Mapa

1. No UnrealEd, vá para Actor > Add Actor
2. Selecione a classe do script que você criou (ex: AethelgardTerrainInfo)
3. Coloque o ator no mapa
4. Configure as propriedades do ator no painel de propriedades
5. Vincule o ator a outros objetos conforme necessário

### Configuração do BiomeManager

1. Adicione um ator BiomeManager ao mapa
2. Configure as propriedades para carregar os arquivos de configuração de bioma
3. Vincule o BiomeManager ao TerrainInfo
4. Configure os parâmetros ambientais para cada bioma

## Adição de Vegetação e Elementos Ambientais

### Importação de Modelos 3D

1. Importe modelos 3D para vegetação (File > Import)
2. Organize os modelos em pacotes por tipo (árvores, arbustos, rochas, etc.)
3. Configure materiais e colisão para cada modelo

### Colocação Manual de Vegetação

1. Selecione um modelo de vegetação
2. Use a ferramenta de colocação para adicionar ao mapa
3. Ajuste posição, rotação e escala conforme necessário
4. Repita para criar áreas de vegetação densa

### Colocação Automática de Vegetação

1. Configure o script TerrainInfo para gerar vegetação automaticamente
2. Defina densidades e tipos de vegetação por bioma
3. Execute a função de geração de vegetação
4. Ajuste manualmente conforme necessário

## Testes e Otimização

### Teste de Desempenho

1. Execute o mapa no modo de jogo (Play > Play Level)
2. Verifique a taxa de quadros (FPS) em diferentes áreas
3. Identifique áreas problemáticas com baixo desempenho

### Otimização do Terreno

1. Ajuste os níveis de detalhe (LOD) do terreno
2. Configure distâncias de renderização apropriadas
3. Otimize a resolução das texturas
4. Reduza a densidade de vegetação em áreas críticas

### Otimização de Iluminação

1. Use iluminação estática quando possível
2. Reduza o número de luzes dinâmicas
3. Configure sombras com níveis de detalhe apropriados
4. Use lightmaps para melhorar o desempenho

## Exportação e Integração Final

### Exportação do Mapa

1. Salve o mapa final (File > Save)
2. Compile o mapa para distribuição (Build > Build All)
3. Empacote o mapa e recursos associados (File > Export)

### Integração com o Servidor

1. Copie os arquivos do mapa para a pasta apropriada no servidor
2. Configure o servidor para carregar o novo mapa
3. Atualize os arquivos de configuração do servidor
4. Reinicie o servidor para aplicar as alterações

### Testes Finais

1. Conecte-se ao servidor com um cliente de jogo
2. Teste o mapa em condições reais de jogo
3. Verifique se todos os biomas estão funcionando corretamente
4. Teste o desempenho com vários jogadores

## Solução de Problemas Comuns

### Problemas de Heightmap

- **Problema**: Terreno com "degraus" ou muito angular
  **Solução**: Aumente a resolução do heightmap ou aplique suavização

- **Problema**: Escala vertical incorreta
  **Solução**: Ajuste o parâmetro HeightScale no TerrainInfo

### Problemas de Textura

- **Problema**: Texturas esticadas ou borradas
  **Solução**: Ajuste o TextureScale ou use texturas de maior resolução

- **Problema**: Transições abruptas entre biomas
  **Solução**: Suavize os weightmaps com ferramentas de desfoque

### Problemas de Desempenho

- **Problema**: Baixo FPS em áreas específicas
  **Solução**: Reduza a densidade de vegetação ou simplifique a geometria

- **Problema**: Uso excessivo de memória
  **Solução**: Otimize texturas, reduza resolução do terreno ou divida o mapa em zonas

### Problemas de Compilação

- **Problema**: Erros de compilação em scripts UnrealScript
  **Solução**: Verifique a sintaxe, referências a classes e dependências

- **Problema**: Falha ao carregar pacotes compilados
  **Solução**: Verifique caminhos de arquivo e dependências de pacotes

## Fluxo de Trabalho Recomendado

Para um desenvolvimento eficiente, recomendamos este fluxo de trabalho:

1. **Planejamento**: Esboce o mapa e defina os biomas
2. **Protótipo**: Crie um heightmap básico e teste no UnrealEd
3. **Iteração**: Refine o heightmap e crie weightmaps para biomas
4. **Configuração**: Configure os arquivos .ini para cada bioma
5. **Implementação**: Integre scripts e configure o terreno no UnrealEd
6. **Detalhamento**: Adicione vegetação e elementos ambientais
7. **Polimento**: Ajuste iluminação, efeitos atmosféricos e sons
8. **Otimização**: Teste e otimize o desempenho
9. **Finalização**: Exporte e integre ao servidor de jogo

Seguindo este guia, você poderá criar mapas e biomas detalhados e imersivos para Aethelgard: Iron Scars, utilizando a mesma tecnologia que tornou Lineage 2 um sucesso.
