# Documento de Design de Jogo (GDD): Aethelgard: Iron Scars

## 1. Visão Geral

Este documento descreve o conceito inicial para um Massively Multiplayer Online Role-Playing Game (MMORPG) fortemente inspirado nas mecânicas clássicas e na atmosfera de jogos como Lineage 2. O objetivo é criar uma experiência imersiva e desafiadora, focada em combate estratégico, progressão de personagem profunda, sistemas sociais robustos baseados em clãs, e uma economia dinâmica impulsionada pelos jogadores, culminando em conflitos políticos e territoriais de larga escala. O público-alvo principal são jovens a partir dos 14 anos, atraídos por jogabilidade competitiva, interação social e a fantasia de poder em um mundo medieval persistente.

O jogo busca recapturar a essência da competição e cooperação que definiram os MMORPGs clássicos, ao mesmo tempo que incorpora elementos modernos de design e tecnologia para garantir uma experiência engajadora e acessível. A inspiração em Lineage se manifesta não apenas nos sistemas, mas também na sensação de um mundo vasto, perigoso e cheio de oportunidades, onde a reputação e o poder são conquistados através de esforço e alianças estratégicas.

## 2. Pilares de Design

Os seguintes pilares fundamentam a experiência de jogo:

*   **Combate Tático e Impactante:** O sistema de combate será uma peça central, enfatizando o posicionamento, o uso correto de habilidades e a sinergia entre diferentes classes. Inspirado no combate de Lineage, buscará ser visualmente claro, mas com profundidade suficiente para recompensar jogadores habilidosos tanto em PvE (Player versus Environment) quanto em PvP (Player versus Player). A sensação de impacto e a importância de cada ação serão cruciais.
*   **Sistema de Classes Profundo e Diversificado:** Os jogadores poderão escolher entre diversas raças e classes, cada uma com um papel distinto no campo de batalha e na sociedade do jogo. A progressão permitirá especializações significativas, incentivando a formação de grupos balanceados e a rejogabilidade. A identidade de cada classe será fortemente marcada por suas habilidades únicas e estilo de jogo.
*   **Economia Orientada pelo Jogador:** A economia será largamente definida pelas ações dos jogadores, com foco no crafting, coleta de recursos (spoil/scavenge) e comércio. Itens raros e equipamentos poderosos serão difíceis de obter, criando um mercado vibrante onde a oferta e a demanda ditam os preços. A classe Anão (ou similar) poderá ter um papel central na produção e distribuição de bens.
*   **Política e Dominação Territorial:** O endgame será fortemente focado na interação social e política através do sistema de clãs. Clãs poderão formar alianças, declarar guerras e competir pelo controle de territórios estratégicos e castelos através de eventos de cerco (Sieges) de larga escala. A posse de territórios conferirá benefícios tangíveis, incentivando a competição constante.
*   **Mundo Persistente e Perigoso:** O mundo do jogo será vasto e cheio de desafios. Áreas de níveis mais altos serão genuinamente perigosas, incentivando a exploração em grupo e a cautela. Eventos dinâmicos e a presença de Raid Bosses e World Bosses criarão pontos de interesse e conflito.

## 3. Mundo do Jogo (Conceito Inicial)

A ambientação será um mundo de fantasia medieval sombria, reminiscente de Aden em Lineage 2, mas com sua própria história, geografia e conflitos. Haverá múltiplas raças jogáveis (como Aethelgardians (Humanos), Sylvan Elves (Elfos), Umbral Technocrats (Elfos Negros), Ironhide Orcs (Orcs) e Deepcore Engineers (Anões)), cada uma com sua própria cultura, arquitetura e zonas iniciais. O mundo será projetado para parecer grande e interconectado, com transições naturais entre diferentes biomas e níveis de perigo.

Para a Fase 1 (MVP), o mundo será mais contido, consistindo em:

*   **Uma Zona Inicial por Raça (ou uma zona inicial unificada):** Para introduzir os jogadores às mecânicas básicas.
*   **Uma Cidade Principal:** Servindo como hub social e comercial inicial (Ex: Aethelgard Prime ou Ironhaven Citadel).
*   **Áreas de Caça Adjacentes:** Zonas de PvE com dificuldade crescente para a progressão inicial (níveis 1-40, por exemplo), como as bordas da Whispering Woods of Eldoria ou as colinas próximas a Scrapfang Peaks.

Expansões futuras adicionarão novas regiões (como The Shattered Plains, The Glimmering Depths, The Skyfall Frontier), continentes, cidades (como Ghalia, the Iron City ou Deepcore Bastion), dungeons complexas (como Starfall Citadel, The Gearwork Labyrinth, The Anomaly Zone) e zonas de endgame com desafios únicos.

## 4. Sistemas Principais (Fase 1 - MVP)

O MVP focará em implementar as fundações essenciais da experiência:

*   **Sistema de Combate:**
    *   Combate baseado em target (clicar no alvo) com habilidades ativadas por hotkeys.
    *   Atributos básicos: HP, MP, Ataque Físico/Mágico, Defesa Física/Mágica, Velocidade de Ataque/Cast, Precisão, Evasão.
    *   Implementação de auto-ataque e habilidades com cooldowns e custo de MP.
    *   Sistema de aggro básico para monstros (PvE).
    *   PvP inicial talvez limitado a zonas específicas ou arenas, com sistema de "flagging" simples (marcar-se para combate).
*   **Sistema de Classes:**
    *   Seleção de Raça na criação do personagem.
    *   Arquétipos Iniciais e Especializações: Os jogadores começarão escolhendo um arquétipo fundamental que se ramificará em classes especializadas. Exemplos de linhas de classe incluem:
        *   **Combatente:** Focado em combate direto (Ex: Rune Knight, Ironclad Gladiator, Aegis Sentinel, Dreadnought, Thunder Warlord).
        *   **Arcanista:** Manipuladores de energias mágicas e/ou tecnológicas (Ex: Archmage, Technomancer, Aether Weaver, Void Caller, Rune Sage).
        *   **Ranger/Atirador:** Especialistas em combate à distância e/ou furtividade (Ex: Sharpshooter, Gunslinger, Pistoleer, Infiltrator, Saboteur, Demolitionist, Shadow Agent).
        *   **Suporte:** Focados em cura, buffs e debuffs (Ex: Cleric, Templar, Field Medic, Chirurgeon, Aetheric Chanter, Rune Warden).
        *   **Artífice/Engenheiro:** Mestres da criação e tecnologia (Ex: Siege Master, Gadgeteer, Weaponsmith Artificer, Golemancer) - talvez mais proeminente entre Deepcore Engineers e Aethelgardians.
    *   Progressão via XP e níveis.
    *   Primeira mudança de classe (ex: Nível 20) com uma pequena árvore de habilidades ativas e passivas para desbloquear.
*   **Inventário e Comércio:**
    *   Inventário pessoal com capacidade limitada (peso ou slots).
    *   Sistema de loot de monstros (itens, moeda do jogo - "Adena" ou similar).
    *   Equipamento de personagem (slots para arma [Ex: Rune-Etched Greatsword, Ghalian Repeater], armadura [Ex: Reinforced Runic Plate, Aether-Weave Robes], acessórios).
    *   Sistema de troca direta entre jogadores (janela de trade).
    *   NPCs mercadores básicos para compra/venda de itens essenciais.
*   **Sistema de Clãs:**
    *   Criação e gerenciamento básico de clãs (convidar/expulsar membros).
    *   Chat de clã dedicado.
    *   Lista de membros do clã.
*   **Progressão:**
    *   Ganho de Experiência (XP) ao derrotar monstros e completar quests simples (se houver).
    *   Sistema de níveis com aumento de atributos base e pontos para distribuir (ou aumento automático).
    *   Desbloqueio de habilidades conforme o nível e a classe.

## 5. Sistemas Futuros (Pós-MVP)

Após a validação do MVP, o desenvolvimento se concentrará em expandir e aprofundar os sistemas:

*   **Expansão do Mundo:** Novas zonas, cidades, dungeons, Raid Bosses, World Bosses.
*   **Profundidade das Classes:** Segunda (e talvez terceira) evolução de classes, árvores de habilidades complexas, mais habilidades únicas.
*   **Sistema de Crafting:** Implementação completa do sistema de criação de itens, com receitas, materiais e o papel central dos Anões (ou classe similar).
*   **Economia Avançada:** Sistema de leilão (Auction House), lojas pessoais de jogadores, impostos sobre transações (ligados a castelos?).
*   **Política e Sieges:** Sistema completo de cercos a castelos, controle territorial, alianças formais, guerras de clãs com regras e consequências.
*   **PvP Avançado:** Arenas ranqueadas, zonas de PvP aberto com penalidades (Karma), eventos de PvP em massa.
*   **Outros Sistemas:** Pets, montarias, sistema de encantamento de itens (enchant), skills de clã, etc.

## 6. Tecnologia (Sugestões)

A escolha da tecnologia é crucial para a viabilidade e escalabilidade do projeto:

*   **Game Engine:** Unreal Engine ou Unity são recomendados devido ao suporte robusto a jogos 3D, vastos marketplaces de assets e comunidades ativas. Unreal Engine pode ser preferível pela qualidade gráfica e ferramentas para mundos grandes, enquanto Unity oferece grande flexibilidade.
*   **Arquitetura de Servidor:** Uma arquitetura distribuída será necessária para suportar um grande número de jogadores simultâneos. C++ é uma opção para máximo desempenho do core do servidor, mas linguagens como C# (com Unity), Java, ou Go também são viáveis. Soluções de Backend-as-a-Service (BaaS) como SpatialOS ou PlayFab podem acelerar o desenvolvimento da infraestrutura, mas adicionam dependência externa.
*   **Banco de Dados:** Uma combinação pode ser ideal. PostgreSQL para dados relacionais (personagens, inventários, clãs) e talvez um NoSQL como Cassandra para dados de alta escrita/leitura (logs, chat, dados de posição).
*   **Rede:** Implementação cuidadosa usando TCP para dados críticos e UDP para dados menos sensíveis (como posição), com estratégias de otimização e segurança.

## 7. Recursos e Considerações

Desenvolver um MMORPG é um desafio significativo que exige recursos substanciais:

*   **Equipe:** Conforme detalhado no documento de escopo, uma equipe multidisciplinar é essencial, cobrindo design, programação (cliente, servidor, ferramentas), arte (2D, 3D, animação, UI/UX, VFX), som, rede/DevOps, QA e gerenciamento.
*   **Tempo e Custo:** Mesmo um MVP pode levar de 1 a 3 anos com uma equipe dedicada. Um jogo completo pode levar 5+ anos. Os custos associados (salários, software, hardware, servidores) são elevados e exigem planejamento financeiro cuidadoso.
*   **Iteração e Feedback:** É vital adotar uma abordagem iterativa, lançando o MVP para um grupo de testes (Alpha/Beta) para coletar feedback e ajustar o design antes de expandir o escopo.

Este GDD preliminar serve como ponto de partida. Ele deve ser expandido e refinado continuamente ao longo do ciclo de desenvolvimento, incorporando mais detalhes sobre cada sistema, mecânica e conteúdo.
