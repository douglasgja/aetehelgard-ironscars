# Pesquisa de Referência: Guia Lineage 2 Interlude

Fonte: https://www.lineage2online.com.br/guia

## Introdução ao Lineage 2 Interlude

*   **O que é Lineage 2?**
    *   MMORPG da NCSoft, conhecido pelo ambiente imersivo e jogabilidade desafiadora. Interlude é uma versão icônica.
*   **História e Ambientação**
    *   **Mundo de Aden**: Fantasia medieval, diversas raças lutando por poder.
    *   **Facções e Raças**: Conflitos entre Humanos, Elfos, Elfos Negros, Orcs, Anões.
*   **Evolução até Interlude**
    *   Interlude introduziu novos conteúdos, refinamentos e melhorias gráficas.

## Criação de Personagem

*   **Escolha da Raça**
    *   **Humanos**: Versáteis (guerreiros, magos, arqueiros).
    *   **Elfos**: Magia de apoio, combate à distância.
    *   **Elfos Negros**: Magia negra, habilidades ofensivas.
    *   **Orcs**: Guerreiros robustos, alta resistência e ataque.
    *   **Anões**: Mestres de criação, coleta de recursos.
*   **Classes e Evolução**
    *   **1ª Profissão (Lvl 20)**: Guerreiro, Mago, Rogue.
    *   **2ª Profissão (Lvl 40)**: Classes avançadas (Gladiator, Spellsinger, etc.).
    *   **3ª Profissão**: Não presente no Interlude.

## Classes e Especializações (Exemplos)

*   **Guerreiros**: Gladiator (duplas), Warlord (AoE), Paladin (defesa/cura), Dark Avenger (invocação).
*   **Magos**: Sorcerer (fogo), Necromancer (negra/invocação), Spellsinger (água/suporte), Spellhowler (vento/escuridão).
*   **Arqueiros**: Hawkeye (humano), Silver Ranger (elfo, vel. ataque), Phantom Ranger (elfo negro, crítico).
*   **Curandeiros/Suporte**: Bishop (cura massa), Elven Elder (cura/mana buff), Shillien Elder (ataque mágico buff).
*   **Summoners**: Warlock, Elemental Summoner, Phantom Summoner.
*   **Tanques**: Temple Knight (res. mágica), Shillien Knight (debuffs/controle).
*   **Buffadores/Debuffadores**: Prophet, Swordsinger (físico), Bladedancer (combate grupo).
*   **Anões**: Scavenger (coleta), Artisan/Warsmith (crafting, golems).

## Progressão e Níveis

*   **Sistema de XP**: Matar monstros, quests, eventos.
*   **Quests Importantes**: De classe (evolução), de recompensas (itens, adena).
*   **Locais de Up Level**: Divididos por faixas de nível (Ex: Iniciais 1-20, Médios 20-40, Avançados 40-60, Altos 60+).

## Equipamentos e Itens

*   **Tipos**: Armas (espadas, arcos, etc.), Armaduras (leves, pesadas, robes).
*   **Sistema de Enchant**: Melhorar propriedades, risco de quebrar item.
*   **Crafting**: Coleta de materiais, receitas/blueprints, papel crucial dos Anões.

## PvE e Dungeons

*   **Monstros e Chefes**: Raid Bosses (grupo), World Bosses (alianças).
*   **Dungeons**: Cruma Tower, Tower of Insolence.

## PvP e Sieges

*   **Sistema de PvP**: Flagging System, recompensas e penalidades.
*   **Castle Sieges**: Participação via clã, estratégias de ataque/defesa, coordenação.
*   **Fortresses e Clãs**: Captura de fortalezas menores, Guerras de Clãs (declaração, alianças).

## Economia do Jogo

*   **Adena e Mercado**: Ganhar/gastar adena, comércio entre jogadores.
*   **Papel dos Anões**: Dominam crafting e spoil (coleta de recursos de monstros), marketplaces, NPC shops.

## Comunidade e Comunicação

*   **Ferramentas**: Chat, mensagens privadas, sistema de clãs.
*   **Eventos**: Sazonais, competições, roleplay, interações sociais.

## Dicas Avançadas

*   Otimização de personagem, rotas de leveling, gestão de recursos.
