# Lista de Tarefas - Criação de MMORPG estilo Lineage

- [x] Coletar requisitos detalhados do MMORPG com o usuário.
- [x] Pesquisar referências de jogos estilo Lineage:
    - [x] Sistema de combate
    - [x] Sistema de classes
    - [x] Economia e comércio
    - [x] Política, clãs e dominação de territórios/castelos
    - [x] Possíveis diferenciais e inovações (análise inicial baseada no guia)
- [x] Definir escopo inicial e recursos necessários (tecnologias, equipe estimada, etc.).
- [x] Criar documento de planejamento inicial (Game Design Document - GDD preliminar).
- [x] Apresentar o documento de planejamento ao usuário e solicitar feedback.
